﻿using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.CustomExceptions;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Api.Controllers
{
    public class PoolDocumentController : GenericController<PoolDocument, CreatePoolDocumentDto, UpdatePoolDocumentDto, ReadPoolDocumentDto>
    {
        private readonly IPoolDocumentService _service;

        public PoolDocumentController(IPoolDocumentService service) : base(service)

        {
            this._service = service;
        }

        [HttpGet("{OptionPoolId}")]
        public async Task<IActionResult> GetOptionPoolDocuments(
        [FromRoute][Required] Guid OptionPoolId,
        [FromServices] IOptionPoolService _optionPoolService)
        {
            var optionPool = await _optionPoolService.GetByIdAsync(OptionPoolId);
            if (optionPool == null)
            {
                ApiException.ClientError("INVALID OPTION POOL ID || FAILED TO RETREIVE OPTION POOL");
            }
            var allDocuments = await _service.GetAllAsync(x => x.OfferPoolId == OptionPoolId);
            return Ok(allDocuments);
        }

        [HttpPost]
        public async Task<IActionResult> UploadPoolDocument(
        [FromForm][Required] CreatePoolDocumentDto dto)
        {
            
            var result = await _service.AddAsync(dto);
            if (result == null)
            {
                ApiException.ClientError("ACTION FAILED",99,result);
            }
            return Ok(result);
        }
    }
}
