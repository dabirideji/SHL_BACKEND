// using System.Linq.Expressions;
// using System.Reflection;
// using Microsoft.AspNetCore.Mvc;
// using LinqKit;
// using SHL.Application.Interfaces;

// namespace SHL.Api.Controllers
// {
//     [ApiController]
//     [Route("api/[controller]/[action]")]
//     public abstract class GenericController<T, TCreateDto, TUpdateDto, TReadDto> : ControllerBase
//             where T : class
//     {
//         private readonly IGenericService<T, TCreateDto, TUpdateDto, TReadDto> _service;

//         protected GenericController(IGenericService<T, TCreateDto, TUpdateDto, TReadDto> service)
//         {
//             _service = service;
//         }

//         [HttpGet]
//         public virtual async Task<IActionResult> GetAll()
//         {
//             var result = await _service.GetAllAsync();
//             return Ok(result);
//         }

//         [HttpGet("{id}")]
//         public virtual async Task<IActionResult> GetById(Guid id)
//         {
//             var result = await _service.GetByIdAsync(id);
//             return Ok(result);
//         }

//         [HttpPost]
//         public virtual async Task<IActionResult> Create([FromBody] TCreateDto createDto)
//         {
//             try
//             {
//                 var responseFromService = await _service.AddAsync(createDto);
//                 // return CreatedAtAction(nameof(GetById), new { id = createDto }, createDto);
//                 return Ok(responseFromService);
//             }
//             catch (System.Exception ex)
//             {
//                 throw;
//             }
//         }

//         [HttpPut("{id}")]
//         public virtual async Task<IActionResult> Update(Guid id, [FromBody] TUpdateDto updateDto)
//         {
//             await _service.UpdateAsync(id, updateDto);
//             return NoContent();
//         }

//         [HttpDelete("{id}")]
//         public virtual async Task<IActionResult> Delete(Guid id)
//         {
//             await _service.DeleteAsync(id);
//             return NoContent();
//         }





//         [HttpPost("datatable")]
//         public virtual async Task<IActionResult> GetDataTable([FromForm] DataTableRequest request)
//         {
//             var queryable = await _service.GetAllAsync(); // This returns IQueryable<TReadDto>

//             // Filtering
//             if (!string.IsNullOrEmpty(request.SearchValue))
//             {
//                 var searchValue = request.SearchValue.ToLower();

//                 // Using reflection to get all properties of TReadDto
//                 var entityType = typeof(TReadDto);
//                 var properties = entityType.GetProperties(BindingFlags.Public | BindingFlags.Instance);

//                 // Dynamically filter on each property of the DTO
//                 var predicate = PredicateBuilder.New<TReadDto>(x => false); // start with an always-false predicate to combine conditions

//                 foreach (var property in properties)
//                 {
//                     // If the property is a string, we can check if it contains the search value
//                     if (property.PropertyType == typeof(string))
//                     {
//                         var parameter = Expression.Parameter(entityType, "x");
//                         var propertyAccess = Expression.MakeMemberAccess(parameter, property);
//                         var searchExpression = Expression.Call(propertyAccess, "Contains", null, Expression.Constant(searchValue, typeof(string)));

//                         predicate = predicate.Or(Expression.Lambda<Func<TReadDto, bool>>(searchExpression, parameter));
//                     }
//                 }

//                 // Apply the filter predicate to the query
//                 queryable = queryable.Where(predicate);
//             }

//             // Sorting (Updated to use TReadDto)
//             if (!string.IsNullOrEmpty(request.SortColumn))
//             {
//                 queryable = SortQueryable(queryable.AsQueryable(), request.SortColumn, request.SortDirection).ToList();
//             }

//             // Pagination
//             var totalRecords = queryable.Count();
//             var data = queryable.Skip(request.Start).Take(request.Length).ToList();

//             return Ok(new
//             {
//                 draw = request.Draw,
//                 recordsTotal = totalRecords,
//                 recordsFiltered = totalRecords,
//                 data
//             });
//         }

//         private IQueryable<TReadDto> SortQueryable(IQueryable<TReadDto> source, string columnName, string direction)
//         {
//             var entityType = typeof(TReadDto);
//             var property = entityType.GetProperty(columnName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

//             if (property == null) return source; // If the property doesn't exist, return as is

//             var parameter = Expression.Parameter(entityType, "x");
//             var propertyAccess = Expression.MakeMemberAccess(parameter, property);
//             var orderByExp = Expression.Lambda(propertyAccess, parameter);

//             string method = direction == "desc" ? "OrderByDescending" : "OrderBy";
//             var resultExp = Expression.Call(typeof(Queryable), method, new Type[] { entityType, property.PropertyType }, source.Expression, Expression.Quote(orderByExp));

//             return source.Provider.CreateQuery<TReadDto>(resultExp);
//         }

//         public class DataTableRequest
//         {
//             public int Draw { get; set; }
//             public int Start { get; set; }
//             public int Length { get; set; }
//             public string SearchValue { get; set; }
//             public string SortColumn { get; set; }
//             public string SortDirection { get; set; }
//         }
//     }
// }




























using System.Linq.Expressions;
using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using LinqKit;
using SHL.Application.Interfaces;

namespace SHL.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public abstract class GenericController<T, TCreateDto, TUpdateDto, TReadDto> : ControllerBase
            where T : class
    {
        private readonly IGenericService<T, TCreateDto, TUpdateDto, TReadDto> _service;

        protected GenericController(IGenericService<T, TCreateDto, TUpdateDto, TReadDto> service)
        {
            _service = service;
        }

        [HttpGet]
        public virtual async Task<IActionResult> GetAll()
        {
            var result = await _service.GetAllAsync();
            return Ok(result);
        }

        [HttpGet("{id}")]
        public virtual async Task<IActionResult> GetById(Guid id)
        {
            var result = await _service.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Create([FromBody] TCreateDto createDto)
        {
            try
            {
                var responseFromService = await _service.AddAsync(createDto);
                // return CreatedAtAction(nameof(GetById), new { id = createDto }, createDto);
                return Ok(responseFromService);
            }
            catch (System.Exception ex)
            {
                throw;
            }
        }

        [HttpPut("{id}")]
        public virtual async Task<IActionResult> Update(Guid id, [FromBody] TUpdateDto updateDto)
        {
            await _service.UpdateAsync(id, updateDto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public virtual async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }


        [HttpPost("datatable")]
        public virtual async Task<IActionResult> GetDataTable([FromBody] DataTableRequest request)
        {
            // Fetching data as IQueryable for further processing
            var queryable = (await _service.GetAllAsync()).AsQueryable();  // Ensure AsQueryable() is used

            // Filtering
            if (!string.IsNullOrEmpty(request.SearchValue))
            {
                string searchValue = request.SearchValue.ToLower();
                var entityType = typeof(TReadDto);
                var properties = entityType.GetProperties(BindingFlags.Public | BindingFlags.Instance);

                var predicate = PredicateBuilder.New<TReadDto>(x => false);

                foreach (var property in properties)
                {
                    if (property.PropertyType == typeof(string)) // Handle only string properties
                    {
                        var parameter = Expression.Parameter(entityType, "x");
                        var propertyAccess = Expression.MakeMemberAccess(parameter, property);
                        var searchExpression = Expression.Call(propertyAccess, "Contains", null,
                            Expression.Constant(searchValue, typeof(string)));

                        predicate = predicate.Or(Expression.Lambda<Func<TReadDto, bool>>(searchExpression, parameter));
                    }
                }

                queryable = queryable.Where(predicate);  // Apply filtering
            }

            // Sorting
            if (!string.IsNullOrEmpty(request.SortColumn))
            {
                queryable = SortQueryable(queryable, request.SortColumn, request.SortDirection); // Apply sorting
            }

            // Pagination
            var totalRecords = queryable.Count();  // Total records before applying pagination
            var data = queryable.Skip(request.Start).Take(request.Length).ToList();  // Apply pagination

            return Ok(new
            {
                draw = request.Draw,
                recordsTotal = totalRecords,
                recordsFiltered = totalRecords,
                data
            });
        }

        private IQueryable<TReadDto> SortQueryable(IQueryable<TReadDto> source, string columnName, string direction)
        {
            var entityType = typeof(TReadDto);
            var property = entityType.GetProperty(columnName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

            if (property == null) return source;  // Return the source unmodified if the column name doesn't match

            var parameter = Expression.Parameter(entityType, "x");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExp = Expression.Lambda(propertyAccess, parameter);

            string method = direction.ToLower() == "desc" ? "OrderByDescending" : "OrderBy";  // Determine whether to order ascending or descending
            var resultExp = Expression.Call(typeof(Queryable), method, new Type[] { entityType, property.PropertyType },
                source.Expression, Expression.Quote(orderByExp));

            return source.Provider.CreateQuery<TReadDto>(resultExp);  // Return the sorted query
        }


        public class DataTableRequest
        {
            public int Draw { get; set; }
            public int Start { get; set; }
            public int Length { get; set; }
            public string SearchValue { get; set; } = "";
            public string SortColumn { get; set; } = "";
            public string SortDirection { get; set; } = "asc";
        }


    }
}