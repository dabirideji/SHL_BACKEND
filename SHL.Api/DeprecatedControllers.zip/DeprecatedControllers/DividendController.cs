﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using SHL.Application.CQRS.Dividend.Commands;
using SHL.Application.CQRS.GenerateDividend.Commands;
using SHL.Application.DTO.Dividend;
using SHL.Application.DTO.GenerateDividend;
using SHL.Application.IServices;
using SHL.Application.ViewModels;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DividendController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly IDividendRepository dividendRepository;
        private readonly IDividendPayoutRequestRepository dividendPayoutRequestRepository;
        private readonly IUserIdentityService userIdentityService;

        public DividendController(IMediator mediator,
            IDividendRepository dividendRepository,
            IDividendPayoutRequestRepository dividendPayoutRequestRepository,
            IUserIdentityService userIdentityService)
        {
            this.mediator = mediator;
            this.dividendRepository = dividendRepository;
            this.dividendPayoutRequestRepository = dividendPayoutRequestRepository;
            this.userIdentityService = userIdentityService;
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpPost("Create")]
        public async Task<ActionResult> CreateAsync([FromBody] GenerateDividendDto model)
        {
            await mediator.Send(new GenerateDividendCommand(model));
            return Ok();
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        [HttpPost("PayoutRequest")]
        public async Task<ActionResult> PayoutRequestAsync([FromBody] DividendPayoutRequestDto model)
        {
            await mediator.Send(new DividendPayoutRequestCommand(model));

            return Ok();
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpPost("PayoutRequest/StatusChange")]
        public async Task<ActionResult> StatusChangeAsync([FromBody] DividendRequestStatusChangedDto model)
        {
            await mediator.Send(new DividendRequestStatusChangedCommand(model));

            return Ok();
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpGet("Employer/Dashboard")]
        public async Task<ActionResult> EmployerDashboard()
        {
            var dividends = await dividendRepository.Get()
                 .AsNoTracking()
                 .ToListAsync();

            var unclaimedAmount = dividends.Sum(s => s.UnClaimedAmount);
            var claimedAmount = dividends.Sum(s => s.ClaimedAmount);
            var totalAmount = unclaimedAmount + claimedAmount;

            var totalRequests = await dividendPayoutRequestRepository.Get()
                .AsNoTracking()
                .Select(s => s.EmployeeEmailAddress)
                .Distinct()
                .CountAsync();

            var viewModel = new DividendDashboardViewModel
            {
                ClaimedAmount = claimedAmount,
                TotalAmount = totalAmount,
                TotalPayoutRequest = totalRequests,
                UnClaimedAmount = unclaimedAmount
            };

            return Ok(viewModel);
        }


        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        [HttpGet("Employee/Dashboard")]
        public async Task<ActionResult> EmployeeDashboard()
        {
            var dividends = await dividendRepository.Get(u => u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking()
                 .ToListAsync();

            var unclaimedAmount = dividends.Sum(s => s.UnClaimedAmount);
            var claimedAmount = dividends.Sum(s => s.ClaimedAmount);
            var totalAmount = unclaimedAmount + claimedAmount;

            var totalRequests = await dividendPayoutRequestRepository.Get(u => u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                .AsNoTracking()
                .Select(s => s.EmployeeEmailAddress)
                .Distinct()
                .CountAsync();

            var viewModel = new DividendDashboardViewModel
            {
                ClaimedAmount = claimedAmount,
                TotalAmount = totalAmount,
                TotalPayoutRequest = totalRequests,
                UnClaimedAmount = unclaimedAmount
            };

            return Ok(viewModel);
        }


        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpGet("Employer/TotalPayoutGraph")]
        public async Task<ActionResult> EmployerTotalPayoutGraph()
        {
            var dividends = await dividendRepository.Get()
                .Where(c => c.Status == Domain.Enums.DividedStatus.Approved.ToString())
                 .GroupBy(g => g.CreatedAt.Date)
                 .ToListAsync();

            var viewModel = new List<TotalPayoutGraphViewModel>();
            foreach (var item in dividends)
            {
                var totalClaimed = item.Sum(s => s.ClaimedAmount);
                var month = item.Key.ToString("MMM");
                viewModel.Add(new TotalPayoutGraphViewModel
                {
                    Month = month,
                    Payout = totalClaimed
                });
            }


            return Ok(viewModel);
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpGet("Employer/ClaimTrendOverTimeGraph")]
        public async Task<ActionResult> EmployerClaimTrendOverTimeGraph()
        {
            var dividends = await dividendRepository.Get()
                .Where(c => c.Status == Domain.Enums.DividedStatus.Approved.ToString())
                 .GroupBy(g => g.CreatedAt.Date)
                 .ToListAsync();

            var viewModel = new List<ClaimUnClaimTrendOverTimeGraphViewModel>();
            foreach (var item in dividends)
            {
                var totalClaimed = item.Sum(s => s.ClaimedAmount);
                var totalUnClaimed = item.Sum(s => s.UnClaimedAmount);
                var month = item.Key.ToString("MMM");
                viewModel.Add(new ClaimUnClaimTrendOverTimeGraphViewModel
                {
                    Month = month,
                    Paid = totalClaimed,
                    UnPaid= totalUnClaimed
                });
            }


            return Ok(viewModel);
        }

        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        [HttpGet("Employee/ClaimTrendOverTimeGraph")]
        public async Task<ActionResult> EmployeeClaimTrendOverTimeGraph()
        {
            var dividends = await dividendRepository.Get(u=>u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                .Where(c => c.Status == Domain.Enums.DividedStatus.Approved.ToString())
                 .GroupBy(g => g.CreatedAt.Date)
                 .ToListAsync();

            var viewModel = new List<ClaimUnClaimTrendOverTimeGraphViewModel>();
            foreach (var item in dividends)
            {
                var totalClaimed = item.Sum(s => s.ClaimedAmount);
                var totalUnClaimed = item.Sum(s => s.UnClaimedAmount);
                var month = item.Key.ToString("MMM");
                viewModel.Add(new ClaimUnClaimTrendOverTimeGraphViewModel
                {
                    Month = month,
                    Paid = totalClaimed,
                    UnPaid = totalUnClaimed
                });
            }


            return Ok(viewModel);
        }



        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        [HttpDelete("Delete/{id}")]
        public async Task<ActionResult> DeleteGenerateDividendAsync(Guid id)
        {
            await mediator.Send(new DeleteGenerateDividendCommand(id));
            return Ok();
        }
    }
}
