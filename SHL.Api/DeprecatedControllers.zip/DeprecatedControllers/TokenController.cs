using Microsoft.AspNetCore.Mvc;
using SHL.Application.CustomExceptions;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;

namespace SHL.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class TokenController : ControllerBase
    {
        private readonly ITokenService _tokenService;
        public TokenController(ITokenService tokenService)
        {
            _tokenService = tokenService;
        }

        [HttpPost]
        public async Task<IActionResult> SendToken([FromBody]SendTokenDto dto)
        {
            var response= await _tokenService.SendToken(dto);
            if(!response)
            {
                ApiException.ClientError("FAIILED TO SEND TOKEN");
            }
            return Ok(response);

        }

        [HttpGet]
        public async Task<IActionResult> VerifyToken([FromQuery]string tk, [FromQuery]string reference)
        {
            var response= await _tokenService.VerifyToken(tk,reference);
            if(!response)
            {
                ApiException.ClientError("FAIILED TO VERIFY TOKEN");
            }
            return Ok(response);

        }
    }
}