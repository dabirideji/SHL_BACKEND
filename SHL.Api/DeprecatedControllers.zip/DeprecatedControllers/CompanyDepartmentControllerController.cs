﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.CompanyDepartment.Commands;
using SHL.Application.DTO.CompanyDepartment;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy =SHLAuthorizationPolicy.Employer)]
    public class CompanyDepartmentController : ControllerBase
    {
        private readonly IMediator mediator;

        public CompanyDepartmentController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost("Create")]
        public async Task<ActionResult> CreateAsync([FromBody]CreateDepartmentDto model)
        {
            await mediator.Send(new CreateDepartmentCommand(model));
            return Ok();
        }
    }
}
