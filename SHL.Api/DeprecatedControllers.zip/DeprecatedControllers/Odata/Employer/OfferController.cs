﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class OfferController:ODataController
    {
        private readonly IOfferRepository offerRepository;

        public OfferController(IOfferRepository offerRepository)
        {
            this.offerRepository = offerRepository;
        }

        [HttpGet("Offer")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var offers = offerRepository.Get()
                 .AsNoTracking();

            return Ok(offers);
        }

        [HttpGet("Offer/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var offer = offerRepository.Get(u => u.Id == key )
                 .AsNoTracking();

            return Ok(SingleResult.Create(offer));
        }
    }
}
