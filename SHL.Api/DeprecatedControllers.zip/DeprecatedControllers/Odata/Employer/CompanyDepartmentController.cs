﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
   // [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class CompanyDepartmentController:ODataController
    {
        private readonly ICompanyDepartmentRepository companyDepartmentRepository;

        public CompanyDepartmentController(ICompanyDepartmentRepository companyDepartmentRepository)
        {
            this.companyDepartmentRepository = companyDepartmentRepository;
        }

        [HttpGet("CompanyDepartment")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = companyDepartmentRepository.Get()
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("CompanyDepartment/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = companyDepartmentRepository.Get(u => u.Id == key)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
