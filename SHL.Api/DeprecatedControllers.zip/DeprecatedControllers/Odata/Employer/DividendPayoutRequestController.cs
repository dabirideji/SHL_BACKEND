﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class DividendPayoutRequestController:ODataController
    {
        private readonly IDividendPayoutRequestRepository dividendPayoutRequestRepository;

        public DividendPayoutRequestController(IDividendPayoutRequestRepository dividendPayoutRequestRepository)
        {
            this.dividendPayoutRequestRepository = dividendPayoutRequestRepository;
        }

        [HttpGet("DividendPayoutRequest")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendPayoutRequestRepository.Get()
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("DividendPayoutRequest/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendPayoutRequestRepository.Get(u => u.Id == key)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
