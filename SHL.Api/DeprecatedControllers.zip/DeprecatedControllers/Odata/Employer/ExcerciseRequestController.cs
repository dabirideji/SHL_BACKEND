﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class ExcerciseRequestController : ODataController
    {
        private readonly IExcerciseRequestRepository excerciseRequestRepository;

        public ExcerciseRequestController(IExcerciseRequestRepository excerciseRequestRepository)
        {
            this.excerciseRequestRepository = excerciseRequestRepository;
        }

        [HttpGet("ExcerciseRequest")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = excerciseRequestRepository.Get()
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("ExcerciseRequest/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = excerciseRequestRepository.Get(u => u.Id == key)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
