﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    public class AppSettingController:ODataController
    {
        private readonly IAppSettingRepository appSettingRepository;

        public AppSettingController(IAppSettingRepository appSettingRepository)
        {
            this.appSettingRepository = appSettingRepository;
        }

        [HttpGet("AppSetting")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var brokers = appSettingRepository.Get()
                 .AsNoTracking();

            return Ok(brokers);
        }

        [HttpGet("AppSetting/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var broker = appSettingRepository.Get(u => u.Id == key)
                 .AsNoTracking();

            return Ok(SingleResult.Create(broker));
        }
    }
}
