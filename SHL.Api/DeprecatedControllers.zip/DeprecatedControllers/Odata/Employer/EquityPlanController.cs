﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy =SHLAuthorizationPolicy.Employer)]
    public class EquityPlanController:ODataController
    {
        private readonly IEquityPlanRepository equityPlanRepository;

        public EquityPlanController(IEquityPlanRepository equityPlanRepository)
        {
            this.equityPlanRepository = equityPlanRepository;
        }

        [HttpGet("EquityPlan")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var brokers = equityPlanRepository.Get()
                 .ToList();

            return Ok(brokers);
        }

        [HttpGet("EquityPlan/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var broker = equityPlanRepository.Get(u => u.Id == key)
                 .AsNoTracking();

            return Ok(SingleResult.Create(broker));
        }
    }
}
