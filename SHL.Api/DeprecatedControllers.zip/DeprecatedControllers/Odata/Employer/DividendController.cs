﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class DividendController:ODataController
    {
        private readonly IDividendRepository dividendRepository;

        public DividendController(IDividendRepository dividendRepository)
        {
            this.dividendRepository = dividendRepository;
        }

        [HttpGet("Dividend")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendRepository.Get()
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("Dividend/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendRepository.Get(u => u.Id == key)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
