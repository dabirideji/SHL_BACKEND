﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class VestedShareTransferController:ODataController
    {
        private readonly IVestedShareTransferRepository vestedShareTransferRepository;

        public VestedShareTransferController(IVestedShareTransferRepository vestedShareTransferRepository)
        {
            this.vestedShareTransferRepository = vestedShareTransferRepository;
        }

        [HttpGet("VestedShareTransfer")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var shareTransfers = vestedShareTransferRepository.Get()
                 .AsNoTracking();

            return Ok(shareTransfers);
        }

        [HttpGet("VestedShareTransfer/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var shareTransfer = vestedShareTransferRepository.Get(u => u.Id == key)
                 .AsNoTracking();

            return Ok(SingleResult.Create(shareTransfer));
        }
    }
}
