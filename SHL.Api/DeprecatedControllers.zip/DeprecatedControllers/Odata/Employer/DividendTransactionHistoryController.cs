﻿

using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class DividendTransactionHistoryController:ODataController
    {
        private readonly IDividendTransactionHistoryRepository dividendTransactionHistoryRepository;

        public DividendTransactionHistoryController(IDividendTransactionHistoryRepository dividendTransactionHistoryRepository)
        {
            this.dividendTransactionHistoryRepository = dividendTransactionHistoryRepository;
        }

        [HttpGet("DividendTransactionHistory")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendTransactionHistoryRepository.Get()
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("DividendTransactionHistory/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendTransactionHistoryRepository.Get(u => u.Id == key)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
