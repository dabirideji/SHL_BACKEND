﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using SHL.Application.Repositories;
using Microsoft.EntityFrameworkCore;

namespace SHL.Api.Controllers.Odata.Employer
{
    [Route("employer/odata")]
    public class BrokerController:ODataController
    {
        private readonly IBrokerRepository brokerRepository;

        public BrokerController(IBrokerRepository brokerRepository)
        {
            this.brokerRepository = brokerRepository;
        }

        [HttpGet("Broker")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var brokers = brokerRepository.Get()
                 .AsNoTracking();

            return Ok(brokers);
        }

        [HttpGet("Broker/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var broker = brokerRepository.Get(u => u.Id == key)
                 .AsNoTracking();

            return Ok(SingleResult.Create(broker));
        }
    }
}
