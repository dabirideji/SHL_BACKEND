﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Domain.Models;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class ShareholderController:ODataController
    {
        private readonly IShareholderRepository shareholderRepository;
        private readonly IUserIdentityService userIdentityService;

        public ShareholderController(IShareholderRepository shareholderRepository,
            IUserIdentityService userIdentityService)
        {
            this.shareholderRepository = shareholderRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("Shareholder")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var shareholders = shareholderRepository.Get(s=>s.ShareholderEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(shareholders);
        }

        [HttpGet("Shareholder/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var shareholder = shareholderRepository.Get(u => u.Id == key && u.ShareholderEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(shareholder));
        }
    }
}
