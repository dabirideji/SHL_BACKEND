﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class ExcerciseRequestController:ODataController
    {
        private readonly IExcerciseRequestRepository excerciseRequestRepository;
        private readonly IUserIdentityService userIdentityService;

        public ExcerciseRequestController(IExcerciseRequestRepository excerciseRequestRepository ,
            IUserIdentityService userIdentityService)
        {
            this.excerciseRequestRepository = excerciseRequestRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("ExcerciseRequest")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = excerciseRequestRepository.Get(u => u.HolderEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("ExcerciseRequest/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = excerciseRequestRepository.Get(u => u.Id == key && u.HolderEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
