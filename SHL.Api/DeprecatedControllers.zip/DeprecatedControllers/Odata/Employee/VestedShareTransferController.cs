﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class VestedShareTransferController:ODataController
    {
        private readonly IVestedShareTransferRepository vestedShareTransferRepository;
        private readonly IUserIdentityService userIdentityService;

        public VestedShareTransferController(IVestedShareTransferRepository vestedShareTransferRepository,
            IUserIdentityService userIdentityService)
        {
            this.vestedShareTransferRepository = vestedShareTransferRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("VestedShareTransfer")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var sharedRequests = vestedShareTransferRepository.Get(o => o.HolderEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(sharedRequests);
        }

        [HttpGet("VestedShareTransfer/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var sharedRequest = vestedShareTransferRepository.Get(u => u.Id == key && u.HolderEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(SingleResult.Create(sharedRequest));
        }
    }
}
