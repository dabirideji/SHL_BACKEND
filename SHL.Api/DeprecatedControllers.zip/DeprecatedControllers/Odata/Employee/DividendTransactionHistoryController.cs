﻿

using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class DividendTransactionHistoryController:ODataController
    {
        private readonly IDividendTransactionHistoryRepository dividendTransactionHistoryRepository;
        private readonly IUserIdentityService userIdentityService;

        public DividendTransactionHistoryController(IDividendTransactionHistoryRepository dividendTransactionHistoryRepository,
            IUserIdentityService userIdentityService)
        {
            this.dividendTransactionHistoryRepository = dividendTransactionHistoryRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("DividendTransactionHistory")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendTransactionHistoryRepository.Get(u=>u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("DividendTransactionHistory/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendTransactionHistoryRepository.Get(u => u.Id == key && u.EmployeeEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
