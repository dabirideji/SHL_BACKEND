﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class DividendController:ODataController
    {
        private readonly IDividendRepository dividendRepository;
        private readonly IUserIdentityService userIdentityService;

        public DividendController(IDividendRepository dividendRepository,
            IUserIdentityService userIdentityService)
        {
            this.dividendRepository = dividendRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("Dividend")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendRepository.Get(u=>u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("Dividend/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendRepository.Get(u => u.Id == key && u.EmployeeEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
