﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class TransactionHistoryController:ODataController
    {
        private readonly ITransactionHistoryRepository transactionHistoryRepository;
        private readonly IUserIdentityService userIdentityService;

        public TransactionHistoryController(ITransactionHistoryRepository transactionHistoryRepository,
            IUserIdentityService userIdentityService)
        {
            this.transactionHistoryRepository = transactionHistoryRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("TransactionHistory")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var histories = transactionHistoryRepository.Get(t=>t.UserEmailAddress == userIdentityService.EmailAddress)
                .OrderBy(d=>d.TransactionDate) 
                .AsNoTracking();

            return Ok(histories);
        }

        [HttpGet("TransactionHistory/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var shareholder = transactionHistoryRepository.Get(u => u.Id == key && u.UserEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(shareholder));
        }
    }
}
