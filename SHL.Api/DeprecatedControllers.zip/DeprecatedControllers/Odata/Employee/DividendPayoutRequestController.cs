﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Results;
using Microsoft.EntityFrameworkCore;
using SHL.Application.IServices;
using SHL.Repository.Repositories;

namespace SHL.Api.Controllers.Odata.Employee
{
    [Route("employee/odata")]
    [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
    public class DividendPayoutRequestController:ODataController
    {
        private readonly IDividendPayoutRequestRepository dividendPayoutRequestRepository;
        private readonly IUserIdentityService userIdentityService;

        public DividendPayoutRequestController(IDividendPayoutRequestRepository dividendPayoutRequestRepository,
            IUserIdentityService userIdentityService)
        {
            this.dividendPayoutRequestRepository = dividendPayoutRequestRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpGet("DividendPayoutRequest")]
        [EnableQuery]
        public ActionResult GetAll()
        {
            var entities = dividendPayoutRequestRepository.Get(u=>u.EmployeeEmailAddress == userIdentityService.EmailAddress)
                 .AsNoTracking();

            return Ok(entities);
        }

        [HttpGet("DividendPayoutRequest/{key}")]
        [EnableQuery]
        public ActionResult GetOne(Guid key)
        {
            var entity = dividendPayoutRequestRepository.Get(u => u.Id == key && u.EmployeeEmailAddress == userIdentityService.EmailAddress)
            .AsNoTracking();

            return Ok(SingleResult.Create(entity));
        }
    }
}
