using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class ContactController : GenericController<Contact, CreateContactDto, UpdateContactDto, ReadContactDto>
    {
        private readonly IContactService _service;

        public ContactController(IContactService service) : base(service)

        {
            this._service = service;
        }
    }
}
