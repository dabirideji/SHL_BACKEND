using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class SubscriptionController : GenericController<Subscription, CreateSubscriptionDto, UpdateSubscriptionDto, ReadSubscriptionDto>
    {
        private readonly ISubscriptionService _service;
        public SubscriptionController(ISubscriptionService service) : base(service)
        {
            this._service = service;
        }
      
    }
}
