﻿using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class PayoutAccountController : GenericController<PayoutAccount, CreatePayoutAccountDto, UpdatePayoutAccountDto, ReadPayoutAccountDto>
    {
        private readonly IPayoutAccountService _service;

        public PayoutAccountController(IPayoutAccountService service) : base(service)

        {
            this._service = service;
        }
      
    }





}
