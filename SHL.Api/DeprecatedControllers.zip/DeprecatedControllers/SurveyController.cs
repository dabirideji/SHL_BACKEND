using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class SurveyController : GenericController<Survey, CreateSurveyDto, UpdateSurveyDto, ReadSurveyDto>
    {
        private readonly ISurveyService _service;

        public SurveyController(ISurveyService service) : base(service)

        {
            this._service = service;
        }}
}
