using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.CustomExceptions;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class VestingScheduleController : GenericController<VestingSchedule, CreateVestingScheduleDto, UpdateVestingScheduleDto, ReadVestingScheduleDto>
    {
        private readonly IVestingScheduleService _service;

        public VestingScheduleController(IVestingScheduleService service) : base(service)

        {
            this._service = service;
        }

        [HttpGet("{GrantId}")]
        public async Task<IActionResult> GetGrantsVestingSchedules([FromRoute] Guid GrantId, [FromServices] IGrantService _grantService)
        {
            var grant = await _grantService.GetByIdAsync(GrantId);
            if (grant == null)
            {
                ApiException.ClientError("INVALID GRANT ID");
            }
            var grantsVestings = await _service.GetAllAsync(x => x.GrantId == GrantId);
            return Ok(grantsVestings);
        }
    }
}