﻿using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;
using SHL.Domain.Models.Categories;

namespace InventoryManagement.Api.Controllers
{
    public class OptionPoolController : GenericController<OptionPool, CreateOptionPoolDto, UpdateOptionPoolDto, ReadOptionPoolDto>
    {
        private readonly IOptionPoolService _service;

        public OptionPoolController(IOptionPoolService service) : base(service)

        {
            this._service = service;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetOptionPools([FromQuery]OptionPoolType? t=OptionPoolType.STOCK_OPTION)
        {
            var allOptions=await _service.GetAllAsync();
            var filtered=allOptions.Where(x=>x.OptionPoolType.ToString().ToUpper()==t.ToString().ToUpper()).ToList();
            return Ok(filtered);
        }
      
    }





}
