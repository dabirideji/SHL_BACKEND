﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.EquityPlan.Commands;
using SHL.Application.DTO.EquityPlan;
using SHL.Application.IServices;
using SHL.Application.Repositories;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy =SHLAuthorizationPolicy.Employer)]
    public class EquityPlanController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly IEquityPlanRepository equityPlanRepository;
        private readonly IUserIdentityService userIdentityService;

        public EquityPlanController(IMediator mediator,
            IEquityPlanRepository equityPlanRepository,
            IUserIdentityService userIdentityService)
        {
            this.mediator = mediator;
            this.equityPlanRepository = equityPlanRepository;
            this.userIdentityService = userIdentityService;
        }

        [HttpPost("Create")]
        public async Task<ActionResult> CreateEquityPlanAsync([FromBody]CreateEquityPlanDto model)
        {
            await mediator.Send(new CreateEquityPlanCommand(model));
            return Ok();
        }

    }
}
