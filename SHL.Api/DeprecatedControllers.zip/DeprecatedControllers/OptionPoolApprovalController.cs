using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class OptionPoolApprovalController : GenericController<OptionPoolApproval, CreateOptionPoolApprovalDto, UpdateOptionPoolApprovalDto, ReadOptionPoolApprovalDto>
    {
        private readonly IOptionPoolApprovalService _service;

        public OptionPoolApprovalController(IOptionPoolApprovalService service) : base(service)

        {
            this._service = service;
        }
      
    }





}
