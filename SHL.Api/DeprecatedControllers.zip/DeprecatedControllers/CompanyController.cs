using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SHL.Api;
using SHL.Api.Controllers;
using SHL.Application.CQRS;
using SHL.Application.CQRS.Company.Commands;
using SHL.Application.DTO.Company;
using SHL.Application.DTO.Company.Request;
using SHL.Application.DTO.Company.Response;
using SHL.Application.Interfaces;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Application.ViewModels;
using SHL.Domain.Models;
using System.Threading.Tasks;

namespace InventoryManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class CompanyController : ControllerBase// GenericController<Company, CreateCompanyDto, UpdateCompanyDto, ReadCompanyDto>
    {
        private readonly ICompanyService _service;
        private readonly IMediator mediator;
        private readonly ICompanyUserRepository companyUserRepository;
        private readonly ICompanyRepository companyRepository;
        private readonly IUserIdentityService userIdentityService;
        private readonly IStaffRepository staffRepository;
        private readonly IOfferRepository offerRepository;
        private readonly IShareholderRepository shareholderRepository;
        private readonly IEquityPlanRepository equityPlanRepository;
        private readonly IWebHostEnvironment webHostEnvironment;
        private readonly IAzureBlobStorageService azureBlobStorageService;

        public CompanyController(ICompanyService service,
            IMediator mediator,
            ICompanyUserRepository companyUserRepository,
            ICompanyRepository companyRepository,
            IUserIdentityService userIdentityService,
            IStaffRepository staffRepository,
            IOfferRepository offerRepository,
            IShareholderRepository shareholderRepository,
            IEquityPlanRepository equityPlanRepository,
            IWebHostEnvironment webHostEnvironment,
            IAzureBlobStorageService azureBlobStorageService) //: base(service)

        {
            this._service = service;
            this.mediator = mediator;
            this.companyUserRepository = companyUserRepository;
            this.companyRepository = companyRepository;
            this.userIdentityService = userIdentityService;
            this.staffRepository = staffRepository;
            this.offerRepository = offerRepository;
            this.shareholderRepository = shareholderRepository;
            this.equityPlanRepository = equityPlanRepository;
            this.webHostEnvironment = webHostEnvironment;
            this.azureBlobStorageService = azureBlobStorageService;
        }

        [HttpPost]
        public async Task<ActionResult> OnboardAsync([FromBody] OnboardDto model)
        {
            await mediator.Send(new OnboardCommand(model));
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult> OnboardVerifyEmailAsync([FromBody] VerifyEmailDto model)
        {
            await mediator.Send(new VerifyEmailCommand(model));
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult> ResendVerifyEmailAsync([FromBody] ResendVerifyEmailDto model)
        {
            await mediator.Send(new ResendVerifyEmailCommand(model));
            return Ok();
        }

        [HttpPost]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> UpdateInfo([FromForm] UpdateCompanyInfoDto model)
        {
            var companyInfo = await mediator.Send(new UpdateCompanyInfoCommand(model));
            return Ok(companyInfo);
        }

        [HttpGet()]
        [Authorize(Policy = SHLAuthorizationPolicy.All)]
        public async Task<ActionResult> Profile()
        {
            var company = await companyRepository.GetByIdAsync(userIdentityService.CompanyId);

            return Ok(company);
        }

        [HttpGet()]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> Staffs()
        {
            var staffs = await staffRepository.CompanyStaffsAsync(userIdentityService.CompanyId);

            return Ok(staffs);
        }

        [HttpGet()]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> CapTable()
        {
            var viewModel = new CapTableViewModel();

            var totalStakeHolders = await offerRepository.Get()
                  .Select(s => s.EquityHolderEmailAddress)
                  .Distinct()
                  .CountAsync();

            var totalSecurity = await equityPlanRepository.Get()
                .SumAsync(s => s.TotalEquity);

            var equityPlan = await equityPlanRepository.Get()
                        .ToListAsync();

            var equities = equityPlan
                          .GroupBy(c => c.EquityType)
                          .ToList();

            viewModel.StakeHolders = totalStakeHolders;
            viewModel.TotalSecurity = totalSecurity;

            var totalAllocatedAndUnAllocated = equityPlan.Sum(s => s.Allocated + s.UnAllocated);

            foreach (var item in equities)
            {
                var allocated = item.Sum(c => c.Allocated);
                var unallocated = item.Sum(c => c.UnAllocated);
                viewModel.AllocatedSecurity.Add(new AllocatedSecurity
                {
                    EquityType = item.Key.ToString(),
                    EquityTypePercentage = (allocated / totalAllocatedAndUnAllocated) * 100M,
                    Total = allocated
                });

                viewModel.UnAllocatedSecurity.Add(new UnAllocatedSecurity
                {
                    EquityType = $"Unallocated {item.Key.ToString()}",
                    EquityTypePercentage = (unallocated / totalAllocatedAndUnAllocated) * 100M,
                    Total = unallocated
                });
            }


            return Ok(viewModel);
        }

        [HttpPost()]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> CreateStaff([FromBody]CreateEmployeeDto model)
        {
            await mediator.Send(new CreateEmployeeCommand(model));
            return Ok();
        }

        [HttpPost()]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> BulkCreateStaff([FromForm] BulkCreateEmployeeDto model )
        {
            await mediator.Send(new BulkCreateEmployeeCommand(model));
            return Ok();
        }

        [HttpPost()]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> EditStaff([FromBody] UpdateEmployeeDto model)
        {
            await mediator.Send(new UpdateEmployeeCommand(model));
            return Ok();
        }

        [HttpPost]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> ChangeStaffStatus([FromBody] ChangeStaffStatusDto model)
        {
            await mediator.Send(new ChangeStaffStatusCommand(model));
            return Ok();
        }

        [HttpGet()]
       // [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> DownloadEmployeeTemplate()
        {
            (byte[] file, string contentType) result = await azureBlobStorageService.DownloadBlobAsync("template", "CreateEmployeeTemplate.xlsx", CancellationToken.None);
            return File(result.file,result.contentType , "bulkemployeeuploadtemplate.xlsx");//"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        

        [HttpPost]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> ToggleAdmin([FromBody] ToggleAdminDto model)
        {
            await mediator.Send(new ToggleAdminCommand(model));
            return Ok();
        }
    }
}
