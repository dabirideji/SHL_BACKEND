using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class OptionHolderSignatureController : GenericController<OptionHolderSignature, CreateOptionHolderSignatureDto, UpdateOptionHolderSignatureDto, ReadOptionHolderSignatureDto>
    {
        private readonly IOptionHolderSignatureService _service;

        public OptionHolderSignatureController(IOptionHolderSignatureService service) : base(service)

        {
            this._service = service;
        }

        public override async Task<IActionResult> Create([FromForm]CreateOptionHolderSignatureDto dto)
        {
            try
            {
                var response = await _service.AddAsync(dto);
                if(response == null)
                {
                    return BadRequest("UNABLE TO CREATE SIGNATURE");
                }
                return Ok(response);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
