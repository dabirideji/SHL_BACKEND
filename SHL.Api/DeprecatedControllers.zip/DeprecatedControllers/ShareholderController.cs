using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class ShareholderController : GenericController<Shareholder, CreateShareholderDto, UpdateShareholderDto, ReadShareholderDto>
    {
        private readonly IShareholderService _service;

        public ShareholderController(IShareholderService service) : base(service)

        {
            this._service = service;
        }
    }
}
