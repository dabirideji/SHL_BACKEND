﻿using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class UploadedDocumentController : GenericController<UploadedDocument, CreateUploadedDocumentDto, UpdateUploadedDocumentDto, ReadUploadedDocumentDto>
    {
        private readonly IUploadedDocumentService _service;

        public UploadedDocumentController(IUploadedDocumentService service) : base(service)

        {
            this._service = service;
        }
        [HttpPost]
        public async Task<IActionResult> UploadFile([FromForm] CreateUploadedDocumentDto dto)
        {
            var res=await _service.AddAsync(dto);
            return Ok(res);
        }
      
    }





}
