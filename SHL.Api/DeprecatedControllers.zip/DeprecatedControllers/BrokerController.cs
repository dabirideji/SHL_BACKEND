﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.Broker.Commands;
using SHL.Application.DTO.Broker;
using SHL.Application.Repositories;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrokerController : ControllerBase
    {
        private readonly IBrokerRepository brokerRepository;
        private readonly IMediator mediator;

        public BrokerController(IBrokerRepository brokerRepository,
            IMediator mediator)
        {
            this.brokerRepository = brokerRepository;
            this.mediator = mediator;
        }

        [HttpGet()]
        public async Task<ActionResult> GetAll()
        {
            var brokers = await brokerRepository.GetAllAsync();

            return Ok(brokers);
        }

        [HttpPost("Create")]
        public async Task<ActionResult> CreateAsync([FromBody]CreateBrokerDto model)
        {
            await mediator.Send(new CreateBrokerCommand(model));
            return Ok();
        }
    }
}
