using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class PortfolioController : GenericController<Portfolio, CreatePortfolioDto, UpdatePortfolioDto, ReadPortfolioDto>
    {
        private readonly IPortfolioService _service;

        public PortfolioController(IPortfolioService service) : base(service)

        {
            this._service = service;
        }

        [HttpGet("{email}")]
        public async Task<IActionResult> GetUserPortfolio([FromRoute] string email)
        {
            var userPortfolio = await _service.GetAllAsync(x =>x.EmployeeEmail.ToLower() == email.ToLower());
            return Ok(userPortfolio);
        }
    }
}
