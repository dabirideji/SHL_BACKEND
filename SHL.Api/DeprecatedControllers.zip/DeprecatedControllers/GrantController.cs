using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class GrantController : GenericController<Grant, CreateGrantDto, UpdateGrantDto, ReadGrantDto>
    {
        private readonly IGrantService _service;

        public GrantController(IGrantService service) : base(service)

        {
            this._service = service;
        }

        //     public async Task<IActionResult> CreateGrant([FromBody] CreateGrantDto dto, [FromServices] IVestingScheduleService _vestScheduleService)
        //     {
        //         try
        //         {
        //             //check
        //             var hasError = false;
        //             var grant = await _service.AddAsync(dto);
        //             if (grant == null)
        //             {
        //                 hasError = true;
        //                 ApiException.ClientError("UNABLE TO CREATE GRANT", 88, new { hasError });
        //             }

        //             var grantId = grant.Id;
        //             foreach (var vesting in dto.Vestings)
        //             {
        //                 vesting.GrantId = grantId;
        //                 var resultFromVesting = await _vestScheduleService.AddAsync(vesting);
        //                 if (resultFromVesting == null)
        //                 {
        //                     hasError = true;
        //                     ApiException.ClientError("UNABLE TO CREATE VESTING", 88, new { hasError, vesting });
        //                 }
        //             }
        //             if (hasError)
        //             {
        //                 ApiException.ClientError("UNABLE TO PERFORM ACTION", 99, new { hasError });
        //             }

        //             return Ok(new { response = "GRANT CREATED SUCCESSFULLY", hasError });
        //         }
        //         catch (Exception)
        //         {

        //             throw;
        //         }
        //     }
        // }

        [HttpPost]
        public async Task<IActionResult> CreateGrant([FromBody] CreateGrantDto dto, [FromServices] IVestingScheduleService vestScheduleService)
        {
            try
            {
                var grant = await _service.AddAsync(dto);
                if (grant == null)
                {
                    return BadRequest(new { error = "Unable to create grant", code = 88 });
                }
                var hasError = false;
                var errors = new List<object>();
                foreach (var vesting in dto.Vestings)
                {
                    vesting.GrantId = grant.Id;
                    var resultFromVesting = await vestScheduleService.AddAsync(vesting);
                    if (resultFromVesting == null)
                    {
                        hasError = true;
                        errors.Add(new { message = "Unable to create vesting", vesting });
                    }
                }
                if (hasError)
                {
                    return BadRequest(new
                    {
                        error = "Unable to perform some actions",
                        code = 99,
                        details = errors
                    });
                }
                return Ok(new { message = "Grant created successfully",grant, hasError });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return StatusCode(500, new { error = "An unexpected error occurred", code = 500 });
            }
        }
    }
}
