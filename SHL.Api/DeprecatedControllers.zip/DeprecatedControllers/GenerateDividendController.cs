﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.GenerateDividend.Commands;
using SHL.Application.DTO.GenerateDividend;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenerateDividendController : ControllerBase
    {
        private readonly IMediator mediator;

        public GenerateDividendController(IMediator mediator)
        {
            this.mediator = mediator;
        }

    }
}
