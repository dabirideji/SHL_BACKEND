﻿using SHL.Api.Controllers;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Domain.Models;

namespace InventoryManagement.Api.Controllers
{
    public class EmploymentDetailController : GenericController<EmploymentDetail, CreateEmploymentDetailDto, UpdateEmploymentDetailDto, ReadEmploymentDetailDto>
    {
        private readonly IEmploymentDetailService _service;

        public EmploymentDetailController(IEmploymentDetailService service) : base(service)

        {
            this._service = service;
        }
      
    }





}
