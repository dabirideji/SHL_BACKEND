﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.ExcerciseRequest.Commands;
using SHL.Application.DTO.ExcerciseRequest;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExcerciseRequestController : ControllerBase
    {
        private readonly IMediator mediator;

        public ExcerciseRequestController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost("ChangeRequestStatus")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> ChangeRequestStatusAsync([FromBody] ChangeRequestStatusDto model)
        {
            await mediator.Send(new ChangeRequestStatusCommand(model));
            return Ok();
        }
    }
}
