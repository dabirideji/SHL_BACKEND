﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.Offer.Commands;
using SHL.Application.CQRS.VestedShareTransfer.Commands;
using SHL.Application.DTO.VestedShareTransfer;
using SHL.Application.Repositories;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VestedShareTransferController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly IVestedShareTransferRepository vestedShareTransferRepository;

        public VestedShareTransferController(IMediator mediator,
            IVestedShareTransferRepository vestedShareTransferRepository)
        {
            this.mediator = mediator;
            this.vestedShareTransferRepository = vestedShareTransferRepository;
        }


        [HttpPost("ChangeStatus")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> ChangeStatusAsync([FromBody] ChangeStatusDto model)
        {
            await mediator.Send(new ChangeVestedShareTransferStatusCommand(model));
            return Ok();
        }

        [HttpPost("SendToBroker")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> SendToBrokerAsync([FromBody] SendToBrokerDto model)
        {
            _= await mediator.Send(new SendToBrokerCommand(model));
            // result.Position = 0;
            // return File(result, "text/csv", "vestedsharedrequest.csv");
            return Ok();
        }

        [Obsolete("Do not use",true)]
        [HttpPost("UploadProcessedShares")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> UploadProcessedSharesAsync([FromForm] UploadProcessedSharesDto model)
        {
            await mediator.Send(new UploadProcessedSharesCommand(model));
            return Ok();
        }

    }
}
