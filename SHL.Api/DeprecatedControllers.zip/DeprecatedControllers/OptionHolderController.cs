﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SHL.Api.Controllers;
using SHL.Application.CustomExceptions;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Application.Interfaces.GenericRepositoryPattern;
using SHL.Domain.Models;
using SHL.Domain.Models.Categories;

namespace InventoryManagement.Api.Controllers
{
    public class OptionHolderController : GenericController<OptionHolder, CreateOptionHolderDto, UpdateOptionHolderDto, ReadOptionHolderDto>
    {
        private readonly IOptionHolderService _service;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IVestingScheduleService _vestingScheduleService;
        private readonly IPoolDocumentService _poolDocumentService;
        private readonly IGrantService _grantService;
        private readonly IOptionPoolService _optionPoolService;

        public OptionHolderController(IOptionHolderService service, IMapper mapper, IUnitOfWork unitOfWork, IVestingScheduleService vestingScheduleService, IPoolDocumentService poolDocumentService, IGrantService grantService, IOptionPoolService optionPoolService) : base(service)

        {
            this._service = service;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _vestingScheduleService = vestingScheduleService;
            _poolDocumentService = poolDocumentService;
            _grantService = grantService;
            _optionPoolService = optionPoolService;
        }


        [HttpGet("{email}")]
        public async Task<IActionResult> GetDashboardInformation([FromRoute] string email)
        {
            //var _vestingActivationRepo = _unitOfWork.GetRepository<VestingActivation>();
            //var _companyRepo = _unitOfWork.GetRepository<Company>();

            //// Get all option holdings for the staff
            //var allOptionHoldings = (await _service.GetAllAsync())
            //    .Where(x => x.OptionHolderEmailAddress.ToLower() == email.ToLower())
            //    .ToList();

            //if (!allOptionHoldings.Any())
            //{
            //    return NotFound("No option holdings found for this staff.");
            //}

            //double totalShares = 0;
            //double totalVested = 0;
            //List<string> transactionHistory = new List<string>();
            //List<ReadPoolDocumentDto> documents = new List<ReadPoolDocumentDto>();

            //foreach (var holding in allOptionHoldings)
            //{
            //    // Get Grant
            //    var grant = await _grantService.GetByIdAsync(holding.OptionHolderGrantId);
            //    if (grant == null) continue;

            //    // Get Option Pool
            //    var optionPool = await _optionPoolService.GetByIdAsync((Guid)grant.GrantOptionPoolId);
            //    if (optionPool == null) continue;

            //    // Get Company
            //    if(optionPool.OptionPoolCompanyId==null){
            //        continue;
            //        // ApiException.ClientError("ERROR GETTING POOL INFORMATION");
            //    }

            //    var company = await _companyRepo.GetByIdAsync((Guid)optionPool.OptionPoolCompanyId);
            //    if (company == null) continue;

            //    // Update total shares
            //    totalShares += holding.OptionHolderAmount;

            //    // Get vested shares from VestingActivations
            //    var vestingActivations = await _vestingActivationRepo.GetAllAsync(x => x.OptionHolderId == holding.Id);
            //    double vestedShares = vestingActivations.Sum(x => x.VestingAmountInShares);
            //    totalVested += vestedShares;

            //    // Add to transaction history
            //    transactionHistory.Add($"Grant Offered: {grant.CreatedAt:yyyy-MM-dd}");
            //    transactionHistory.Add($"Vesting Started: {grant.CreatedAt.AddYears(3):yyyy-MM-dd}");

            //    if (holding.OptionHolderStatus.ToString().ToUpper() == "EXERCISED")
            //    {
            //        transactionHistory.Add($"Grant Exercised: {grant.GrantExercisePrice} at {DateTime.UtcNow:yyyy-MM-dd}");
            //    }

            //    // Get Documents
            //    var poolDocuments = await _poolDocumentService.GetAllAsync(x => x.OfferPoolId == optionPool.Id);
            //    documents.AddRange(poolDocuments);
            //}

            //// Calculate unvested shares
            //double totalUnvested = totalShares - totalVested;

            //var response = new
            //{
            //    Email = email,
            //    TotalShares = totalShares,
            //    TotalVested = totalVested,
            //    TotalUnvested = totalUnvested,
            //    TransactionHistory = transactionHistory,
            //    Documents = documents
            //};

            //return Ok(response);

            return Ok();
        }


        [HttpGet("{email}")]
        public async Task<IActionResult> GetUserOptionsByEmail(
            [FromRoute] string email)
        {
            //var _vestingActivationRepo = _unitOfWork.GetRepository<VestingActivation>();
            //var _companyRepo = _unitOfWork.GetRepository<Company>();
            //var all = await _service.GetAllAsync();
            //var allOptions = all.Where(x => x.OptionHoldingIsSent == true).ToList();
            //var userOptions = allOptions.Where(x => x.OptionHolderEmailAddress.ToLower() == email.ToLower());

            //var userPortfolioData = new List<UserOptionPortfolioDetails>();
            //var random = new Random();

            //foreach (var item in userOptions)
            //{
            //    // get details.
            //    var grant = _mapper.Map<Grant>(await _grantService.GetByIdAsync(item.OptionHolderGrantId));

            //    if (grant == null)
            //    {
            //        ApiException.ClientError("CANNOT PERFORM ACTION || FAILED GETTING GRANT INFORMATION");
            //    }
            //    var optionPool = _mapper.Map<OptionPool>(await _optionPoolService.GetByIdAsync((Guid)grant.GrantOptionPoolId));

            //    if (optionPool == null)
            //    {
            //        ApiException.ClientError("CANNOT PERFORM ACTION || FAILED GETTING POOL INFORMATION");
            //    }
            //    var company = await _companyRepo.GetByIdAsync((Guid)optionPool.OptionPoolCompanyId);
            //    if (company == null)
            //    {
            //        ApiException.ClientError("CANNOT PERFORM ACTION || FAILED GETTING COMPANY INFO");
            //    }

            //    double holdingPercentage = (double)item.OptionHolderAmount / optionPool.OptionPoolTotalShares * 100;
            //    double dilutedOwnership = Math.Round(random.NextDouble() * (holdingPercentage - 0.5) + 0.5, 2);

            //    var dto = new UserOptionPortfolioDetails();

            //    dto.UserEmail = email;
            //    dto.OptionHoldingId = item.Id.ToString();
            //    dto.OfferId = grant.Id.ToString();
            //    dto.EstimatedOwnership = Math.Round(holdingPercentage, 2);
            //    // dto.EstimatedOwnershipCurrency = company.CompanyCurrencyCode.ToUpper() ?? "NGN";
            //    dto.EstimatedOwnershipCurrency = "NGN";
            //    dto.ShareAmount = (int)item.OptionHolderAmount;
            //    dto.SharePrice = company.CompanySharePriceValuation + 1;
            //    dto.TotalShareValue = item.OptionHolderAmount * (company.CompanySharePriceValuation + 1);
            //    dto.ShareType = optionPool.OptionPoolType.ToString().ToUpper();
            //    dto.DilutedOwnership = dilutedOwnership;
            //    dto.VestingStatus = item.OptionHolderVestingStatus;
            //    dto.IsSent = item.OptionHoldingIsSent;
            //    dto.IsSigned = item.OptionHoldingIsSigned;

            //    // GRANT TYPE
            //    dto.OptionType = optionPool.OptionPoolType.ToString().ToUpper();
            //    dto.OptionPrice = item.OptionHolderAmount * (grant.GrantStrikePrice + 1);
            //    dto.ExercisePrice = grant.GrantExercisePrice + 1;
            //    dto.OfferType = optionPool.OptionPoolType.ToString().ToUpper();
            //    dto.OptionsPoolName = optionPool.OptionPoolName;
            //    dto.OptionStatus = item.OptionHolderStatus.ToString().ToUpper() == "APPROVED" ? "PENDING" : item.OptionHolderStatus.ToString().ToUpper();
            //    dto.StartDate = grant.CreatedAt.ToString("yyyy-MM-dd");
            //    dto.VestingStartDate = grant.CreatedAt.AddYears(3).ToString("yyyy-MM-dd");

            //    // Async operations
            //    dto.VestingSchedule = (await _vestingScheduleService.GetAllAsync(x => x.GrantId == grant.Id)).ToList();
            //    dto.VestingActivations = (await _vestingActivationRepo.GetAllAsync(x => x.OptionHolderId == item.Id)).ToList();
            //    dto.Documents = (await _poolDocumentService.GetAllAsync(x => x.OfferPoolId == optionPool.Id)).ToList();


            //    userPortfolioData.Add(dto);
            //}

            //return Ok(userPortfolioData); // 🔥 FIX: Return the array directly, not inside a wrapper object
            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> ApproveOptionHoldings([FromBody] BulkActionDto optionHoldings)
        {
            return Ok();
            //var _repo = _unitOfWork.GetRepository<OptionHolder>();
            //var _portfolioRepo = _unitOfWork.GetRepository<Portfolio>();
            //var _optionPoolRepo = _unitOfWork.GetRepository<OptionPool>();
            //var _grantRepo = _unitOfWork.GetRepository<Grant>();
            //var _companyRepo = _unitOfWork.GetRepository<Company>();
            //var _vestingActivationsRepo = _unitOfWork.GetRepository<VestingActivation>();

            //var allHoldings = await _repo.GetAllAsync();

            //foreach (string optionHoldingId in optionHoldings.ListOfId)
            //{
            //    var optionHolding = allHoldings.FirstOrDefault(x => x.Id.ToString() == optionHoldingId);
            //    if (optionHolding == null || optionHolding.OptionHolderStatus == OptionHolderStatus.APPROVED)
            //        continue;

            //    var grant = await _grantRepo.GetByIdAsync(optionHolding.OptionHolderGrantId);
            //    if (grant == null)
            //    {

            //        ApiException.ClientError("INVALID GRANT DATA");
            //    }

            //    var optionPool = await _optionPoolRepo.GetByIdAsync((Guid)grant.GrantOptionPoolId);

            //    if (optionPool == null)
            //    {

            //        ApiException.ClientError("INVALID POOL DATA");
            //    }

            //    if (optionPool.OptionPoolCompanyId == null)
            //    {
            //        ApiException.ClientError("ERROR GETTING COMPANY INFORMATION");
            //    }
            //    var company = await _companyRepo.GetByIdAsync((Guid)optionPool.OptionPoolCompanyId);
            //    if (company == null)
            //    {

            //        ApiException.ClientError("INVALID COMPANY DATA");
            //    }

            //    // Add portfolio entry
            //    await _portfolioRepo.AddAsync(new Portfolio
            //    {
            //        CompanyName = company.CompanyName.ToUpper(),
            //        DilutedOwnershipPercentage = optionHolding.OptionHolderDilutedEquityPercentage,
            //        EmployeeEmail = optionHolding.OptionHolderEmailAddress,
            //        EmployeeId = optionHolding.OptionHolderStaffId,
            //        OptionId = optionHolding.OptionHolderGrantId,
            //        TotalShareUnits = optionHolding.OptionHolderAmount,
            //        TotalShareValuation = 0.2891
            //    });

            //    // Approve option holding
            //    optionHolding.OptionHolderStatus = OptionHolderStatus.APPROVED;
            //    optionHolding.OptionHoldingIsSent = true;
            //    // Generate vesting activations
            //    var vestingActivations = await GenerateVestingActivations(optionHolding.Id, optionHolding.OptionHolderAmount);

            //    await _vestingActivationsRepo.AddRangeAsync(vestingActivations);
            //    await _repo.UpdateAsync(optionHolding);
            //    await _unitOfWork.SaveChangesAsync();
            //}

            //return Ok(new { RESPONSE = "OPTIONHOLDERS APPROVED SUCCESSFULLY" });
        }

        [HttpPost]
        public async Task<IActionResult> RejectOptionHoldings([FromBody] BulkActionDto Optionholdings, [FromServices] IUnitOfWork _unitOfWork)
        {
            return Ok();
            //var _repo = _unitOfWork.GetRepository<OptionHolder>();
            //var allHoldings = await _repo.GetAllAsync();
            //foreach (string optionHoldingId in Optionholdings.ListOfId)
            //{
            //    // fetch holding
            //    var optionHolding = allHoldings.FirstOrDefault(x => x.Id.ToString() == optionHoldingId);
            //    if (optionHolding != null)
            //    {
            //        optionHolding.OptionHolderStatus = OptionHolderStatus.REJECTED;
            //        await _repo.UpdateAsync(optionHolding);
            //        await _unitOfWork.SaveChangesAsync();
            //    }
            //}
            //return Ok(new
            //{
            //    RESPONSE = "OPTIONHOLDERS REJECTED SUCCESSFULLY"
            //});
        }

        #region PRIVATE UTILITY METHODS

        private async Task<List<VestingActivation>> GenerateVestingActivations(Guid optionHolderId, double totalForVesting)
        {
            return new List<VestingActivation>();
            //var optionHolding = await _unitOfWork.GetRepository<OptionHolder>().GetByIdAsync(optionHolderId);
            //if (optionHolding == null)
            //    ApiException.ClientError("Option Holder not found.");

            //var vestingSchedules = await _unitOfWork.GetRepository<VestingSchedule>().GetAllAsync(vs => vs.GrantId == optionHolding.OptionHolderGrantId);
            //if (!vestingSchedules.Any())
            //    ApiException.ClientError("No vesting schedule found for this grant.");

            //var vestingActivations = new List<VestingActivation>();
            //double remainingShares = totalForVesting, vestedSoFar = 0;

            //foreach (var schedule in vestingSchedules)
            //{
            //    DateTime vestingDate = schedule.StartDate ?? DateTime.UtcNow;

            //    // Handle Cliff Vesting
            //    if (schedule.VestingType == VestingType.CLIFF_VESTING && schedule.VestSpecificAmount.HasValue)
            //    {
            //        vestingActivations.Add(CreateVestingActivation(optionHolderId, schedule.Id, vestingDate.AddMonths(schedule.VestingForValue ?? 12),
            //            schedule.VestSpecificAmount.Value, true));

            //        vestedSoFar += schedule.VestSpecificAmount.Value;
            //        remainingShares -= schedule.VestSpecificAmount.Value;
            //    }

            //    // Handle Periodic Vesting
            //    if (schedule.VestingEveryValue.HasValue && schedule.VestAmountInUnit.HasValue)
            //    {
            //        int periods = schedule.VestingForValue ?? 1;
            //        double vestingPerPeriod = totalForVesting / periods;

            //        for (int i = 1; i <= periods; i++)
            //        {
            //            if (vestedSoFar >= totalForVesting) break;

            //            vestingActivations.Add(CreateVestingActivation(optionHolderId, schedule.Id,
            //                vestingDate.AddMonths(i * schedule.VestingEveryValue.Value), vestingPerPeriod, false));

            //            vestedSoFar += vestingPerPeriod;
            //            remainingShares -= vestingPerPeriod;
            //        }
            //    }
            //}

            //return vestingActivations;
        }

        private VestingActivation CreateVestingActivation(Guid optionHolderId, Guid scheduleId, DateTime activationDate, double amount, bool isCliff)
        {
            return new VestingActivation
            {
                OptionHolderId = optionHolderId,
                VestingScheduleId = scheduleId,
                VestingActivationDate = activationDate,
                VestingRelativePercentage = (amount / amount) * 100,
                VestingDilutedPercentage = (amount / 1000000) * 100, // Example denominator, adjust as needed
                VestingOpeningPercentage = 25,
                VestingAmountInShares = amount,
                VestingAmountInValuation = amount * 0.2891,
                IsCliff = isCliff,
                VestingStatus = Status.PENDING
            };
        }
        #endregion

    }
}