﻿using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.IServices;
using SHL.Application.Services;
using SHL.Repository.Repositories;
using System.Net.Mail;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SampleController : ControllerBase
    {
        private readonly IExcelProcessor excelProcessor;
        private readonly IMailService mailService;

        public SampleController(IExcelProcessor excelProcessor,
            IMailService mailService)
        {
            this.excelProcessor = excelProcessor;
            this.mailService = mailService;
        }

        [HttpPost("test")]
        public async Task<ActionResult> TestAsync()
        {
            var approvedRequests = new List<Domain.Models.VestedShareTransfer> {

                new Domain.Models.VestedShareTransfer
            {
                ApprovalDate = DateTime.UtcNow,
                BrokerId = Guid.NewGuid(),
                ChnNumber = "1234",
                CompanyId = Guid.NewGuid(),
                CscsNumber = "12345",
                HolderEmailAddress = "johndoe@sample.com",
                HolderName = "John Doe",
                ReferenceNumber = "12345",
                Status = "Approve"
            }
                };
            var csvStream = await excelProcessor.ConvertToCsv(approvedRequests);

            // csvStream.Position = 0;
            var stream = new MemoryStream(csvStream);
            var attachment = new Attachment(stream, "vestedsharedrequest.csv", "text/csv");
            await mailService.SendMailWithAttachmentAsync("olamidejames007@gmail.com", "Please find attached vested shared request", "Vested Shared Request", [attachment]);

            return Ok();
        }
    }
}
