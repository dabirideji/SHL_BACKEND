﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.Account.Commands;
using SHL.Application.DTO.Account;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IMediator mediator;

        public AccountController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost("ForgotPassword/SendLink")]
        public async ValueTask<ActionResult> SendForgotPasswordLink(string emailAddress)
        {
            await mediator.Send(new ForgotPasswordCommand(emailAddress));
            return Ok();
        }

        [HttpPost("ResetPassword")]
        public async ValueTask<ActionResult> ResetPassword([FromBody] ResetPasswordDto model)
        {
            await mediator.Send(new ResetPasswordCommand(model));
            return Ok();
        }

        [HttpPost("ChangePassword")]
        [Authorize]
        public async ValueTask<ActionResult> ChangePassword([FromBody] ChangePasswordDto model)
        {
            await mediator.Send(new ChangePasswordCommand(model));
            return Ok();
        }

        [HttpPost("Employee/UpdateProfile")]
        public async ValueTask<ActionResult> EmployeeInfoUpdate([FromBody] EmployeeInfoUpdateDto model)
        {
            await mediator.Send(new EmployeeInfoUpdateCommand(model));
            return Ok();
        }


    }
}
