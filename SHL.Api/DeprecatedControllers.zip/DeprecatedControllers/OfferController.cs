﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SHL.Application.CQRS.Offer.Commands;
using SHL.Application.DTO.Offer;
using SHL.Application.IServices;
using SHL.Application.Repositories;
using SHL.Application.ViewModels;
using SHL.Domain.Enums;
using SHL.Domain.Models.Categories;
using SHL.Infrastructure.Services;
using System.Security.Cryptography;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OfferController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly IOfferRepository offerRepository;
        private readonly IUserIdentityService userIdentityService;
        private readonly IEquityPlanRepository equityPlanRepository;
        private readonly IWebHostEnvironment webHostEnvironment;
        private readonly IAzureBlobStorageService azureBlobStorageService;
        private readonly ICompanyRepository companyRepository;
        private readonly IShareholderRepository shareholderRepository;

        public OfferController(IMediator mediator,
            IOfferRepository offerRepository,
            IUserIdentityService userIdentityService,
            IEquityPlanRepository equityPlanRepository,
            IWebHostEnvironment webHostEnvironment,
            IAzureBlobStorageService azureBlobStorageService,
            ICompanyRepository companyRepository,
            IShareholderRepository shareholderRepository)
        {
            this.mediator = mediator;
            this.offerRepository = offerRepository;
            this.userIdentityService = userIdentityService;
            this.equityPlanRepository = equityPlanRepository;
            this.webHostEnvironment = webHostEnvironment;
            this.azureBlobStorageService = azureBlobStorageService;
            this.companyRepository = companyRepository;
            this.shareholderRepository = shareholderRepository;
        }

        [HttpGet("EmployerOffers")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> GetEmployerOffers()
        {
            var result = await offerRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet("EmployerOffer/{offerId}")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> GetEmployerOffer(Guid offerId)
        {
            var result = await offerRepository.GetByIdAsync(offerId);
            return Ok(result);
        }


        [HttpGet("EmployeeOffers")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        public async Task<ActionResult> GetEmployeeOffers()
        {
            var result = await offerRepository.GetAllAsync(u => u.EquityHolderEmailAddress == userIdentityService.EmailAddress);
            return Ok(result);
        }

        [HttpGet("EmployeeOffer/{offerId}")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> GetEmployeeOffer(Guid offerId)
        {
            var result = (await offerRepository.GetAllAsync(u => u.EquityHolderEmailAddress == userIdentityService.EmailAddress && u.Id == offerId)).FirstOrDefault();
            return Ok(result);
        }

        [HttpPost("BulkUpload")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> OfferBulkUploadAsync([FromForm] OfferBulkUploadDto model)
        {
            var result = await mediator.Send(new OfferBulkUploadCommand(model));
            return Ok(result);
        }

        [HttpPost("Create")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> CreateOfferAsync([FromForm] CreateOfferDto model)
        {
            await mediator.Send(new CreateOfferCommand(model));
            return Ok();
        }

        [HttpPost("Send")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> SendOfferAsync([FromBody] SendOfferDto model)
        {
            await mediator.Send(new SendOfferCommand(model));
            return Ok();
        }

        [HttpPost("Sign")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        public async Task<ActionResult> SignOfferAsync([FromForm] SignOfferDto model)
        {
            await mediator.Send(new SignOfferCommand(model));
            return Ok();
        }


        [HttpPost("ChangeStatus/{offerId}/{status}")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> ChangeStatus(Guid offerId, string status)
        {
            await mediator.Send(new ChangeStatusCommand(offerId, status));
            return Ok();
        }

        [HttpPost("TransferRequest/{offerId}")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        public async Task<ActionResult> VestedOfferTransferRequest(VestedOfferTransferRequestDto model)
        {
            await mediator.Send(new VestedOfferTransferRequestCommand(model));
            return Ok();
        }

        [HttpGet("Portfolio")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        public async Task<ActionResult> Portfolio()
        {


            var offers = await (from off in offerRepository.Get()
                                join eq in equityPlanRepository.Get() on off.EquityPlanId equals eq.Id
                                where off.EquityHolderEmailAddress == userIdentityService.EmailAddress &&
                                off.Status == Offer.Vesting.ToString() || off.Status == Offer.Vested.ToString()
                                //group eq by eq.EquityType into grouping
                                //from g in grouping
                                select new
                                {
                                    Granted = off.OfferValue,
                                    Balance = off.BalanceOfferValue,
                                    VestStartDate = off.VestStartDate,
                                    VestEndDate = off.VestEndDate,
                                    VestingPeriod = off.VestingPeriod,
                                    GrantDate = off.GrantDate,
                                    Status = off.Status,
                                    EquityType = eq.EquityType
                                }).OrderBy(c=>c.EquityType).ToListAsync();


            var equityType = (from eq in offers
                              group eq by eq.EquityType into grouping
                              select new Application.ViewModels.Portfolio
                              {
                                  EquityType = grouping.Key.ToString(),
                                  Granted = grouping.Sum(f => f.Granted),
                                  Vested = grouping.Where(x => x.EquityType == grouping.Key && x.Status == Domain.Enums.Offer.Vested.ToString()).Sum(s => s.Granted),
                                  UnVested = grouping.Where(x => x.EquityType == grouping.Key && x.Status == Domain.Enums.Offer.Vesting.ToString()).Sum(s => s.Granted)
                              }).ToList();


            var totalPortfolio = offers.Sum(o => o.Granted);
            var employeePortfolio = new EmployeePortfolioViewModel
            {
                Portfolios = equityType,
                TotalGranted = totalPortfolio
            };

            employeePortfolio.Share = await shareholderRepository.GetShareholderByEmailAsync(userIdentityService.EmailAddress);
            employeePortfolio.TotalGranted = employeePortfolio.TotalGranted + (employeePortfolio.Share != null ? employeePortfolio.Share.Holding : 0.0M);

            return Ok(employeePortfolio);
        }

        [HttpGet("DownloadTemplate")]
        //[Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> DownloadTemplate()
        {
            (byte[] file, string contentType) result = await azureBlobStorageService.DownloadBlobAsync("template", "offertemplate.xlsx", CancellationToken.None);
            return File(result.file, result.contentType, "bulkemployeeuploadtemplate.xlsx");//"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }

        [HttpGet("Employee/Dashboard")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employee)]
        public async Task<ActionResult> EmployeeDashboard()
        {
            var offers = await offerRepository.Get(u => u.EquityHolderEmailAddress == userIdentityService.EmailAddress)
                .ToListAsync();

            var employeeOffers = offers.Where(o => o.Status != Offer.Pending.ToString()
            && o.Status != Offer.AwaitingVesting.ToString());

            var totalOwnership = employeeOffers.Sum(s => s.OfferValue);

            var vestedShares = offers.Where(s => s.Status == Offer.Vested.ToString())
                .Sum(s => s.OfferValue);

            var unVestedShares = offers.Where(s => s.Status == Offer.Vesting.ToString())
                .Sum(s => s.OfferValue);

            var equityCount = employeeOffers.Count();

            var viewModel = new EmployeeOfferDashboard
            {
                TotalOwnership = totalOwnership,
                VestedShares = vestedShares,
                UnVestedShares = unVestedShares,
                EquityCount = equityCount
            };

            return Ok(viewModel);
        }

        [HttpGet("Employer/Dashboard")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> EmployerDashboard()
        {
            var offers = await offerRepository.Get()
                .ToListAsync();

            var unAllocated = equityPlanRepository.Get().Sum(s => s.UnAllocated);

            var employeeOffers = offers.Where(o => o.Status != Offer.Pending.ToString()
            && o.Status != Offer.AwaitingVesting.ToString());

            var totalOwnership = employeeOffers.Sum(s => s.OfferValue);

            var vestedShares = offers.Where(s => s.Status == Offer.Vested.ToString())
                .Sum(s => s.OfferValue);

            var unVestedShares = offers.Where(s => s.Status == Offer.Vesting.ToString())
                .Sum(s => s.OfferValue);

            var equityCount = employeeOffers.DistinctBy(c => c.EquityHolderEmailAddress).Count();

            var viewModel = new EmployeeOfferDashboard
            {
                TotalOwnership = totalOwnership,
                VestedShares = vestedShares,
                UnVestedShares = unVestedShares,
                EquityCount = equityCount,
                UnAllocated = unAllocated
            };

            return Ok(viewModel);
        }

        [HttpPost("Undo")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> UndoAsync([FromBody] UndoOfferDto model)
        {
            await mediator.Send(new UndoOfferCommand(model));
            return Ok();
        }


        [HttpPost("ExcerciseRequest")]
        public async Task<ActionResult> ExcerciseRequestAsync([FromBody] ExcerciseRequestDto model)
        {
            await mediator.Send(new ExcerciseRequestCommand(model));

            return Ok();
        }

        [HttpGet("Owners")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> Owners()
        {
            var owners = new List<OfferOwner>();

            var companyInfo = await companyRepository.Get(u => u.Id == userIdentityService.CompanyId)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            var offers = await offerRepository.Get(u => u.Status == Domain.Enums.Offer.Vesting.ToString() || u.Status == Offer.Vested.ToString())
                .Include(e => e.EquityPlan)
                .AsNoTracking()
                .OrderByDescending(c => c.OfferValue)
                .Skip(0).Take(5)
                .ToListAsync();

            var totalSecurity = await equityPlanRepository.Get()
               .SumAsync(s => s.TotalEquity);

            var rsu = offers.Where(e => e.EquityPlan.EquityType == EquityType.Rsu)
                .GroupBy(g => new
                {
                    Email = g.EquityHolderEmailAddress,
                    Name = g.OfferHolder,
                    Status = g.Status
                })
                .Select(s => new
                {
                    Name = s.Key.Name,
                    Email = s.Key.Email,
                    Status = s.Key.Status,
                    TotalOffer = s.Sum(s => s.OfferValue)
                })
                .ToList();

            var vestedRsus = rsu.Where(c => c.Status == Domain.Enums.Offer.Vested.ToString())
                .Select(s => new Owner
                {
                    Name = s.Name,
                    EmailAddress = s.Email,
                    Status = s.Status,
                    TotalValue = s.TotalOffer
                }).ToList();

            owners = BuildOfferOwnerData(owners, vestedRsus, Domain.Enums.Offer.Vested.ToString(), EquityType.Rsu);

            var unvestedRsu = rsu.Where(c => c.Status == Domain.Enums.Offer.Vesting.ToString())
              .Select(s => new Owner
              {
                  Name = s.Name,
                  EmailAddress = s.Email,
                  Status = s.Status,
                  TotalValue = s.TotalOffer
              }).ToList();
            owners = BuildOfferOwnerData(owners, unvestedRsu, Domain.Enums.Offer.Vesting.ToString(), EquityType.Rsu);


            var options = offers.Where(e => e.EquityPlan.EquityType == EquityType.Options)
                .GroupBy(g => new
                {
                    Email = g.EquityHolderEmailAddress,
                    Name = g.OfferHolder,
                    Status = g.Status
                })
                .Select(s => new
                {
                    Name = s.Key.Name,
                    Email = s.Key.Email,
                    Status = s.Key.Status,
                    TotalOffer = s.Sum(s => s.OfferValue)
                })
                .ToList();

            var vestedOptions = options.Where(c => c.Status == Domain.Enums.Offer.Vested.ToString())
               .Select(s => new Owner
               {
                   Name = s.Name,
                   EmailAddress = s.Email,
                   Status = s.Status,
                   TotalValue = s.TotalOffer
               }).ToList();

            owners = BuildOfferOwnerData(owners, vestedOptions, Domain.Enums.Offer.Vested.ToString(), EquityType.Options);

            var unvestedOptions = options.Where(c => c.Status == Domain.Enums.Offer.Vesting.ToString())
              .Select(s => new Owner
              {
                  Name = s.Name,
                  EmailAddress = s.Email,
                  Status = s.Status,
                  TotalValue = s.TotalOffer
              }).ToList();
            owners = BuildOfferOwnerData(owners, unvestedOptions, Domain.Enums.Offer.Vesting.ToString(), EquityType.Options);

            foreach (var owner in owners)
            {
                owner.TotalSecurities = owner.VestedOptions + owner.UnVestedOptions + owner.VestedRsu + owner.UnVestedRsu;
                owner.Ownership = Math.Round((owner.TotalSecurities / totalSecurity) * 100.0M, 2);
                owner.TotalValue = companyInfo != null ? (decimal.Parse(companyInfo.CompanySharePriceValuation.ToString()) * owner.TotalSecurities).ToString("N2") : "-";
            }
            return Ok(owners);
        }


        List<OfferOwner> BuildOfferOwnerData(List<OfferOwner> offerOwners, List<Owner> owners, string status, EquityType equityType)
        {
            foreach (var owner in owners)
            {
                var offerOwner = offerOwners.FirstOrDefault(c => c.EmailAddress == owner.EmailAddress);
                if (offerOwner is not null)
                {
                    //Vested Rsu
                    if (equityType == EquityType.Rsu && status == Offer.Vested.ToString())
                    {
                        offerOwner.VestedRsu = owner.TotalValue;
                    }

                    //unvested rsu
                    if (equityType == EquityType.Rsu && status == Offer.Vesting.ToString())
                    {
                        offerOwner.UnVestedRsu = owner.TotalValue;
                    }

                    //Vested Options
                    if (equityType == EquityType.Options && status == Offer.Vested.ToString())
                    {
                        offerOwner.VestedOptions = owner.TotalValue;
                    }

                    //unvested Options
                    if (equityType == EquityType.Options && status == Offer.Vesting.ToString())
                    {
                        offerOwner.UnVestedOptions = owner.TotalValue;
                    }
                }
                else
                {
                    var newOfferOwner = new OfferOwner()
                    {
                        EmailAddress = owner.EmailAddress,
                        Name = owner.Name
                    };
                    if (equityType == EquityType.Rsu && status == Offer.Vested.ToString())
                    {
                        newOfferOwner.VestedRsu = owner.TotalValue;
                    }

                    //unvested rsu
                    if (equityType == EquityType.Rsu && status == Offer.Vesting.ToString())
                    {
                        newOfferOwner.UnVestedRsu = owner.TotalValue;
                    }

                    //Vested Options
                    if (equityType == EquityType.Options && status == Offer.Vested.ToString())
                    {
                        newOfferOwner.VestedOptions = owner.TotalValue;
                    }

                    //unvested Options
                    if (equityType == EquityType.Options && status == Offer.Vesting.ToString())
                    {
                        newOfferOwner.UnVestedOptions = owner.TotalValue;
                    }

                    offerOwners.Add(newOfferOwner);
                }
            }

            return offerOwners;
        }
    }
}
