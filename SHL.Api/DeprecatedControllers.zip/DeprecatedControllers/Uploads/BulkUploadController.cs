using Microsoft.AspNetCore.Mvc;
using SHL.Application.Interfaces;

namespace BulkUploadAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BulkUploadController : ControllerBase
    {
        private readonly IBulkUploadService _bulkUploadService;
        private readonly IShareholderService _shareholderService;
        public BulkUploadController(IBulkUploadService bulkUploadService, IShareholderService shareholderService)
        {
            _bulkUploadService = bulkUploadService;
            _shareholderService = shareholderService;
        }

        [HttpPost("upload-bulk-shareholders/{CompanyId}")]
        public async Task<IActionResult> UploadFile([FromRoute]Guid CompanyId,IFormFile file)
        {
            var result = await _bulkUploadService.UploadFile(CompanyId,file);
            return Ok(result);
        }
    }
}