using AutoMapper;
using ExcelDataReader;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CustomExceptions;
using SHL.Application.DTO.Company.Request;
using SHL.Application.Interfaces;
using SHL.Application.Interfaces.GenericRepositoryPattern;
using SHL.Domain.Models;
using System.Globalization;

[ApiController]
[Route("api/[controller]")]
public class BulkGrantUploadController : ControllerBase
{
    private readonly IOptionPoolService _optionPoolService;
    private readonly IGrantService _grantService;
    private readonly IOptionHolderService _optionHolderService;
    private readonly IStaffService _staffService;
    private readonly IVestingScheduleService _vestingScheduleService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public BulkGrantUploadController(
        IOptionPoolService optionPoolService,
        IGrantService grantService,
        IOptionHolderService optionHolderService,
        IStaffService staffService,
        IVestingScheduleService vestingScheduleService,
        IUnitOfWork unitOfWork,
        IMapper mapper)
    {
        _optionPoolService = optionPoolService;
        _grantService = grantService;
        _optionHolderService = optionHolderService;
        _staffService = staffService;
        _vestingScheduleService = vestingScheduleService;
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    [HttpPost("upload-bulk-grants/{poolId}")]
    public async Task<IActionResult> UploadFile(IFormFile file, [FromRoute] Guid poolId)
    {
        try
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { Message = "File is not selected or empty." });
            }

            const long maxFileSize = 1L * 1024 * 1024 * 1024; // Allow up to 1GB
            if (file.Length > maxFileSize)
            {
                return BadRequest(new { Message = "File size exceeds the 1GB limit." });
            }

            string tempFilePath = Path.Combine(Path.GetTempPath(), file.FileName);
            using (var fileStream = new FileStream(tempFilePath, FileMode.Create))
            {
                await file.CopyToAsync(fileStream);
            }

            // BackgroundJob.Enqueue(() => ProcessFileInBackground(tempFilePath, poolId));
            // return Ok(new { Message = "File uploaded successfully. Processing in background." });

            var response = await ProcessFileInBackground(tempFilePath, poolId);
            if (response)
            {
                return Ok(new { Message = "FILE PROCESSED SUCCESSFULLY" });
            }
            return BadRequest("UPLOAD FAILED");
        }
        catch (Exception ex)
        {
            ApiException.ServerError("UPLOAD FAILED DUE TO EXCEPTION", 500, new { Message = "Internal Server Error", Error = ex.Message });
        }
        return BadRequest("UPLOAD FAILED");
    }


    [NonAction]
    public async Task<bool> ProcessFileInBackground(string filePath, Guid poolId)
    {
        //try
        //{
        //    var _companyRepo = _unitOfWork.GetRepository<Company>();
        //    var _vestingScheduleRepo = _unitOfWork.GetRepository<VestingSchedule>();

        //    var optionHolders = new List<CreateOptionHolderDto>();
        //    var staffList = new List<CreateStaffDto>();
        //    var vestingSchedules = new List<CreateVestingScheduleDto>();

        //    // Retrieve Option Pool
        //    var optionPool = await _optionPoolService.GetByIdAsync(poolId);
        //    if (optionPool == null) ApiException.ClientError("Option Pool not found.");

        //    var companyId = optionPool.OptionPoolCompanyId;
        //    if (companyId == null) ApiException.ClientError("ERROR FETCHING COMPANY INFORMATION");

        //    var company = await _companyRepo.GetByIdAsync((Guid)companyId);

        //    var staffData = new Dictionary<string, List<CreateStaffDto>>();
        //    var divisionGrantMap = new Dictionary<string, double>();
        //    var divisionVestingDates = new Dictionary<string, DateTime>();
        //    var divisionAllocatedUnits = new Dictionary<string, double>();
        //    var totalAllocatedUnits = 0D;
        //    // Read Excel File
        //    using (var stream = System.IO.File.OpenRead(filePath))
        //    using (var reader = ExcelReaderFactory.CreateReader(stream))
        //    {
        //        bool isHeaderRow = true;
        //        string[] headers = null;

        //        while (reader.Read())
        //        {
        //            if (isHeaderRow)
        //            {
        //                headers = new string[reader.FieldCount];
        //                for (int i = 0; i < reader.FieldCount; i++)
        //                    headers[i] = reader.GetString(i) ?? $"Column{i}";

        //                isHeaderRow = false;
        //                continue;
        //            }

        //            var rowData = new Dictionary<string, string>();
        //            for (int i = 0; i < reader.FieldCount; i++)
        //                rowData[headers[i]] = reader.GetValue(i)?.ToString() ?? string.Empty;

        //            string email = rowData.GetValueOrDefault("Email");
        //            string name = rowData.GetValueOrDefault("Name");
        //            string division = rowData.GetValueOrDefault("Division");
        //            string grade = rowData.GetValueOrDefault("Grade");
        //            double allocatedUnits = double.TryParse(rowData.GetValueOrDefault("Total Units", "0"), out double totalUnits) ? totalUnits : 0;//    Convert.ToString(rowData.GetValueOrDefault("Total Units", "0")).Trim();



        //            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(division))
        //            {
        //                continue;
        //            }

        //            totalAllocatedUnits += allocatedUnits;
        //            // Parse Vesting Date
        //            DateTime vestingDate = DateTime.UtcNow.AddYears(3);
        //            string vestingDateString = rowData.GetValueOrDefault("Vesting date")?.Trim().TrimEnd('.');

        //            if (!string.IsNullOrEmpty(vestingDateString) &&
        //                DateTime.TryParseExact(vestingDateString, "MMM d, yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
        //            {
        //                vestingDate = parsedDate;
        //            }

        //            // Store vesting date per division
        //            divisionVestingDates[division] = vestingDate;

        //            if (!staffData.ContainsKey(division))
        //                staffData[division] = new List<CreateStaffDto>();

        //            staffData[division].Add(new CreateStaffDto
        //            {
        //                StaffCompanyId = (Guid)companyId,
        //                Username = email,
        //                FirstName = name.Split(' ')[0],
        //                LastName = name.Split(' ').Skip(1).FirstOrDefault() ?? "Unknown",
        //                Email = email,
        //                PhoneNumber = "0000000000",
        //                Password = "defaultPassword",
        //                StaffDepartment = division,
        //                StaffGrade = grade
        //            });

        //            if (!divisionGrantMap.ContainsKey(division))
        //                divisionGrantMap[division] = 0;

        //            if (!divisionAllocatedUnits.ContainsKey(email))
        //                divisionAllocatedUnits[email] = allocatedUnits;
        //        }
        //    }

        //    // Ensure pool has enough shares

        //    if (totalAllocatedUnits > optionPool.OptionPoolTotalSharesAvailable)
        //        ApiException.ClientError("Insufficient shares in the pool.");

        //    // Create Grants & Vesting Schedules
        //    var createdGrants = new Dictionary<string, Guid>();
        //    foreach (var division in divisionGrantMap.Keys)
        //    {
        //        // Retrieve correct vesting date
        //        DateTime vestingDate = divisionVestingDates.ContainsKey(division) ? divisionVestingDates[division] : DateTime.UtcNow.AddYears(3);

        //        var grant = new CreateGrantDto
        //        {
        //            GrantOptionPoolId = optionPool.Id,
        //            GrantShareAmountTotal = divisionGrantMap[division],
        //            GrantStrikePrice = 10.0,
        //            GrantTargetEmails = staffData[division].Select(s => s.Email).ToList()
        //        };

        //        var createdGrant = await _grantService.AddAsync(grant);
        //        createdGrants[division] = createdGrant.Id;

        //        // Create Vesting Schedule
        //        vestingSchedules.Add(new CreateVestingScheduleDto
        //        {
        //            GrantId = createdGrant.Id,
        //            VestingType = SHL.Domain.Models.Categories.VestingType.TIME_BASED_VESTING,
        //            VestingForPeriod = SHL.Domain.Models.Categories.VestingRecursionType.YEARS,
        //            VestingForValue = 3,
        //            VestingEveryPeriod = SHL.Domain.Models.Categories.VestingRecursionType.MONTHS,
        //            VestingEveryValue = 12,
        //            VestSpecificAmount = divisionGrantMap[division] * 0.25,
        //            VestRelativePercentage = 100,
        //            StartDate = DateTime.UtcNow,
        //            EndDate = vestingDate,
        //            ExpiryDate = vestingDate.AddYears(2)
        //        });
        //    }

        //    // Save Vesting Schedules
        //    var mappedVestSchedules = _mapper.Map<List<VestingSchedule>>(vestingSchedules);
        //    await _vestingScheduleRepo.AddRangeAsync(mappedVestSchedules);

        //    // Insert Staff
        //    var existingStaff = await _staffService.GetAllAsync();
        //    var existingStaffEmails = existingStaff.Select(s => s.Email).ToHashSet();
        //    var newStaffList = staffData.Values.SelectMany(s => s)
        //        .Where(s => !existingStaffEmails.Contains(s.Email))
        //        .ToList();

        //    var savedStaff = await _staffService.AddRangeAsync(newStaffList);
            
        //    var staffDictionary = savedStaff.ToDictionary(s => s.CompanyUser.Email, s => s.Id);

        //    // Create Option Holders with Correct Amount from Excel
        //    foreach (var division in staffData.Keys)
        //    {
        //        foreach (var staff in staffData[division])
        //        {
        //            var staffId = staffDictionary.ContainsKey(staff.Email)
        //                ? staffDictionary[staff.Email]
        //                : existingStaff.First(s => s.Email == staff.Email).Id;

        //            var optionHolderAmount = divisionGrantMap.ContainsKey(division) ? divisionGrantMap[division] : 0;

        //            optionHolders.Add(new CreateOptionHolderDto
        //            {
        //                OptionHolderEmailAddress = staff.Email,
        //                OptionHolderAmount = divisionAllocatedUnits[staff.Email ?? ""], // ✅ Now using total units from Excel
        //                OptionHolderStaffId = staffId,
        //                OptionHolderGrantId = createdGrants[division] // Keeping this the same
        //            });
        //        }
        //    }

        //    await _optionHolderService.AddRangeAsync(optionHolders);
        //    System.IO.File.Delete(filePath);
        //    return true;
        //}
        //catch (Exception ex)
        //{
        //    Console.WriteLine($"Error processing file: {ex.Message}");
        //}
        return false;
    }





































































    // [NonAction]
    // public async Task<bool> ProcessFileInBackground(string filePath, Guid poolId)
    // {
    //     try
    //     {
    //         var _companyRepo = _unitOfWork.GetRepository<Company>();
    //         var _vestingScheduleRepo = _unitOfWork.GetRepository<VestingSchedule>();

    //         var optionHolders = new List<CreateOptionHolderDto>();
    //         var staffList = new List<CreateStaffDto>();
    //         var vestingSchedules = new List<CreateVestingScheduleDto>();

    //         // Retrieve Option Pool
    //         var optionPool = await _optionPoolService.GetByIdAsync(poolId);
    //         if (optionPool == null) ApiException.ClientError("Option Pool not found.");

    //         var companyId = optionPool.OptionPoolCompanyId;
    //         if (companyId == null) ApiException.ClientError("ERROR FETCHING COMPANY INFORMATION");

    //         var company = await _companyRepo.GetByIdAsync((Guid)companyId);

    //         var staffData = new Dictionary<string, List<CreateStaffDto>>();
    //         var divisionGrantMap = new Dictionary<string, double>();
    //         var divisionVestingDates = new Dictionary<string, DateTime>();

    //         // Read Excel File
    //         using (var stream = System.IO.File.OpenRead(filePath))
    //         using (var reader = ExcelReaderFactory.CreateReader(stream))
    //         {
    //             bool isHeaderRow = true;
    //             string[] headers = null;

    //             while (reader.Read())
    //             {
    //                 if (isHeaderRow)
    //                 {
    //                     headers = new string[reader.FieldCount];
    //                     for (int i = 0; i < reader.FieldCount; i++)
    //                         headers[i] = reader.GetString(i) ?? $"Column{i}";

    //                     isHeaderRow = false;
    //                     continue;
    //                 }

    //                 var rowData = new Dictionary<string, string>();
    //                 for (int i = 0; i < reader.FieldCount; i++)
    //                     rowData[headers[i]] = reader.GetValue(i)?.ToString() ?? string.Empty;

    //                 string email = rowData.GetValueOrDefault("Email");
    //                 string name = rowData.GetValueOrDefault("Name");
    //                 string division = rowData.GetValueOrDefault("Division");
    //                 string grade = rowData.GetValueOrDefault("Grade");
    //                 string totalUnitsString = Convert.ToString(rowData.GetValueOrDefault("Total Units", "0")).Trim();

    //                 double totalUnits = 0;
    //                 if (!string.IsNullOrEmpty(totalUnitsString) && double.TryParse(totalUnitsString, out double parsedUnits))
    //                 {
    //                     totalUnits = parsedUnits;
    //                 }
    //                 if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(division))
    //                 {
    //                     continue;
    //                 }

    //                 // Parse Vesting Date
    //                 DateTime vestingDate = DateTime.UtcNow.AddYears(3);
    //                 string vestingDateString = rowData.GetValueOrDefault("Vesting date")?.Trim().TrimEnd('.');

    //                 if (!string.IsNullOrEmpty(vestingDateString) &&
    //                     DateTime.TryParseExact(vestingDateString, "MMM d, yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
    //                 {
    //                     vestingDate = parsedDate;
    //                 }

    //                 // Store vesting date per division
    //                 divisionVestingDates[division] = vestingDate;

    //                 if (!staffData.ContainsKey(division))
    //                     staffData[division] = new List<CreateStaffDto>();

    //                 staffData[division].Add(new CreateStaffDto
    //                 {
    //                     StaffCompanyId = (Guid)companyId,
    //                     Username = email,
    //                     FirstName = name.Split(' ')[0],
    //                     LastName = name.Split(' ').Skip(1).FirstOrDefault() ?? "Unknown",
    //                     Email = email,
    //                     PhoneNumber = "0000000000",
    //                     Password = "defaultPassword",
    //                     StaffDepartment = division,
    //                     StaffGrade = grade
    //                 });

    //                 if (!divisionGrantMap.ContainsKey(division))
    //                     divisionGrantMap[division] = 0;

    //                 divisionGrantMap[division] += totalUnits;
    //             }
    //         }

    //         // Ensure pool has enough shares
    //         double totalRequiredShares = divisionGrantMap.Values.Sum();
    //         if (totalRequiredShares > optionPool.OptionPoolTotalSharesAvailable)
    //             ApiException.ClientError("Insufficient shares in the pool.");

    //         // Create Grants & Vesting Schedules
    //         var createdGrants = new Dictionary<string, Guid>();
    //         foreach (var division in divisionGrantMap.Keys)
    //         {
    //             // Retrieve correct vesting date
    //             DateTime vestingDate = divisionVestingDates.ContainsKey(division) ? divisionVestingDates[division] : DateTime.UtcNow.AddYears(3);

    //             var grant = new CreateGrantDto
    //             {
    //                 GrantOptionPoolId = optionPool.Id,
    //                 GrantShareAmountTotal = divisionGrantMap[division],
    //                 GrantStrikePrice = 10.0,
    //                 GrantTargetEmails = staffData[division].Select(s => s.Email).ToList()
    //             };

    //             var createdGrant = await _grantService.AddAsync(grant);
    //             createdGrants[division] = createdGrant.Id;

    //             // Create Vesting Schedule
    //             vestingSchedules.Add(new CreateVestingScheduleDto
    //             {
    //                 GrantId = createdGrant.Id,
    //                 VestingType = SHL.Domain.Models.Categories.VestingType.TIME_BASED_VESTING,
    //                 VestingForPeriod = SHL.Domain.Models.Categories.VestingRecursionType.YEARS,
    //                 VestingForValue = 3,
    //                 VestingEveryPeriod = SHL.Domain.Models.Categories.VestingRecursionType.MONTHS,
    //                 VestingEveryValue = 12,
    //                 VestSpecificAmount = divisionGrantMap[division] * 0.25,
    //                 VestRelativePercentage = 100,
    //                 StartDate = DateTime.UtcNow,
    //                 EndDate = vestingDate,
    //                 ExpiryDate = vestingDate.AddYears(2)
    //             });
    //         }

    //         // Save Vesting Schedules
    //         var mappedVestSchedules = _mapper.Map<List<VestingSchedule>>(vestingSchedules);
    //         await _vestingScheduleRepo.AddRangeAsync(mappedVestSchedules);

    //         // Insert Staff
    //         var existingStaff = await _staffService.GetAllAsync();
    //         var existingStaffEmails = existingStaff.Select(s => s.Email).ToHashSet();
    //         var newStaffList = staffData.Values.SelectMany(s => s)
    //             .Where(s => !existingStaffEmails.Contains(s.Email))
    //             .ToList();

    //         var savedStaff = await _staffService.AddRangeAsync(newStaffList);
    //         var staffDictionary = savedStaff.ToDictionary(s => s.Email, s => s.Id);

    //         // Create Option Holders
    //         foreach (var division in staffData.Keys)
    //         {
    //             foreach (var staff in staffData[division])
    //             {
    //                 var staffId = staffDictionary.ContainsKey(staff.Email)
    //                     ? staffDictionary[staff.Email]
    //                     : existingStaff.First(s => s.Email == staff.Email).Id;

    //                 optionHolders.Add(new CreateOptionHolderDto
    //                 {
    //                     OptionHolderEmailAddress = staff.Email,
    //                     OptionHolderAmount = 1000,
    //                     OptionHolderStaffId = staffId,
    //                     OptionHolderGrantId = createdGrants[division]
    //                 });
    //             }
    //         }

    //         await _optionHolderService.AddRangeAsync(optionHolders);
    //         System.IO.File.Delete(filePath);
    //         return true;
    //     }
    //     catch (Exception ex)
    //     {
    //         Console.WriteLine($"Error processing file: {ex.Message}");
    //     }
    //     return false;
    // }










}
