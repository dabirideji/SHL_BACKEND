﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.File.Commands;
using SHL.Application.DTO.Company.Request;
using SHL.Application.DTO.File;
using SHL.Application.IServices;

namespace SHL.Api.Controllers.Uploads
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
    public class FileController : ControllerBase
    {
        private readonly IMediator mediator;

        public FileController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost("Upload")]
        public async Task<ActionResult> UploadAsync([FromForm]UploadDto model)
        {
            var url = await mediator.Send(new UploadFileCommand(model));
            return Ok(url);
        }
    }
}
