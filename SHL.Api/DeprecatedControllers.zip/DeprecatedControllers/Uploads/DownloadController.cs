using Microsoft.AspNetCore.Mvc;
using SHL.Application.CustomExceptions;

namespace BulkUploadAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DownloadController : ControllerBase
    {
        [HttpGet("DownloadFile")]
        public IActionResult DownloadFile([FromQuery] string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                ApiException.ClientError("File path is required.");
            }

            var fullPath = Path.Combine("wwwroot", filePath); // Adjust the path based on your storage
            if (!System.IO.File.Exists(fullPath))
            {
                ApiException.ClientError("File not found.");
            }

            var fileBytes = System.IO.File.ReadAllBytes(fullPath);
            var contentType = "application/octet-stream";
            var fileName = Path.GetFileName(fullPath);

            return File(fileBytes, contentType, fileName);
        }

    }
}