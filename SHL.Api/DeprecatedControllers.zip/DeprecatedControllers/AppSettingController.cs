﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SHL.Application.CQRS.AppSetting.Commands;
using SHL.Application.DTO.AppSetting;

namespace SHL.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppSettingController : ControllerBase
    {
        private readonly IMediator mediator;

        public AppSettingController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost("Update")]
        [Authorize(Policy = SHLAuthorizationPolicy.Employer)]
        public async Task<ActionResult> UpdateAsync([FromBody] UpdateSettingDto model)
        {
            var result = await mediator.Send(new UpdateSettingCommand(model));
            return Ok(result);
        }
    }
}
